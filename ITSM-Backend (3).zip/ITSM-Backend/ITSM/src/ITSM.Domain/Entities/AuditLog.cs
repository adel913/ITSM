namespace ITSM.Domain.Entities;

public class AuditLog : BaseEntity
{
    public Guid? UserId { get; set; }
    public string Action { get; set; } = string.Empty; // Login, Logout, UserCreated, PasswordReset, DepartmentChanged, PermissionChanged
    public string? Details { get; set; }
    public string? IpAddress { get; set; }

    // Added for hardening item 13 (audit logs must identify which entity was affected).
    // Nullable so existing call sites that don't pass these keep working unchanged.
    public string? EntityType { get; set; }
    public string? EntityId { get; set; }
}
