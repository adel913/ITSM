namespace ITSM.Domain.Entities;

public class Permission : BaseEntity
{
    public string Module { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string Code => $"{Module}.{Action}";

    public ICollection<RolePermission> RolePermissions { get; set; } = new List<RolePermission>();
}
