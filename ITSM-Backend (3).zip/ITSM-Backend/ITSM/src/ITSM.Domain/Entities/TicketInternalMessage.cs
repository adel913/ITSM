namespace ITSM.Domain.Entities;

// Internal IT Conversation channel: visible only to IT Department users.
public class TicketInternalMessage : BaseEntity
{
    public Guid TicketId { get; set; }
    public Ticket Ticket { get; set; } = null!;

    public Guid SenderId { get; set; }
    public User Sender { get; set; } = null!;

    public string Message { get; set; } = string.Empty;
}
