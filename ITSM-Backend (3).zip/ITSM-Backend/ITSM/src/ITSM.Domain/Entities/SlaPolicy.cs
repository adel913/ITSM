using ITSM.Domain.Enums;

namespace ITSM.Domain.Entities;

public class SlaPolicy : BaseEntity
{
    public TicketPriority Priority { get; set; }
    public int ResponseMinutes { get; set; }
    public int ResolutionMinutes { get; set; }
}
