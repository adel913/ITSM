using System.ComponentModel.DataAnnotations;
using ITSM.Domain.Enums;

namespace ITSM.Domain.Entities;

public class Ticket : BaseEntity
{
    public string TicketNumber { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;

    public Guid CategoryId { get; set; }
    public TicketCategory Category { get; set; } = null!;

    public Guid CreatedById { get; set; }
    public User CreatedBy { get; set; } = null!;

    // Added for hardening item 3 (department isolation). Snapshotted from CreatedBy's
    // department at ticket creation time, since Ticket previously had no department link
    // at all (only a Category). Required to filter ticket visibility by department.
    public Guid DepartmentId { get; set; }
    public Department Department { get; set; } = null!;

    public Guid? AssignedToId { get; set; }
    public User? AssignedTo { get; set; }

    public TicketStatus Status { get; set; } = TicketStatus.New;

    // NOTE: Not explicitly listed in the Phase 2 Ticket Fields list, but required because
    // the SLA Policy table is keyed by Priority and SLA rules reference "the ticket's priority"
    // implicitly. Added as the minimum necessary field to satisfy the stated SLA logic.
    public TicketPriority Priority { get; set; } = TicketPriority.Medium;

    public DateTime? AssignedAt { get; set; }
    public DateTime? FirstResponseAt { get; set; }
    public DateTime? ResolvedAt { get; set; }
    public DateTime? ClosedAt { get; set; }

    // SLA fields
    public DateTime? ResponseDueAt { get; set; }
    public DateTime? ResolutionDueAt { get; set; }
    public bool IsResponseSlaBreached { get; set; } = false;
    public bool IsResolutionSlaBreached { get; set; } = false;
    public int TotalPausedMinutes { get; set; } = 0;
    public DateTime? PauseStartedAtUtc { get; set; }

    public ICollection<TicketConversationMessage> ConversationMessages { get; set; } = new List<TicketConversationMessage>();
    public ICollection<TicketInternalMessage> InternalMessages { get; set; } = new List<TicketInternalMessage>();
    public ICollection<TicketAttachment> Attachments { get; set; } = new List<TicketAttachment>();

    // Added for hardening item 11 (optimistic concurrency).
    [Timestamp]
    public byte[] RowVersion { get; set; } = Array.Empty<byte>();
}
