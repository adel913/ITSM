namespace ITSM.Domain.Entities;

public class Department : BaseEntity
{
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public Guid? ManagerId { get; set; }
    public User? Manager { get; set; }
    public bool IsActive { get; set; } = true;

    // Added for hardening item 15. Department previously had no soft-delete; DeleteAsync
    // used to call DbContext.Remove (hard delete). Replaced with this flag + a global
    // query filter so existing Department rows referenced by historical Tickets/Users
    // are preserved.
    public bool IsDeleted { get; set; } = false;

    public ICollection<User> Users { get; set; } = new List<User>();
}
