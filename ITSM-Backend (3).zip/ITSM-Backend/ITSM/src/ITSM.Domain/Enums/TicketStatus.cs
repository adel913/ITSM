namespace ITSM.Domain.Enums;

public enum TicketStatus
{
    New = 0,
    InProgress = 1,
    PendingUser = 2,
    PendingVendor = 3,
    Resolved = 4,
    Closed = 5,
    Cancelled = 6
}
