namespace ITSM.Domain.Enums;

public enum NotificationEvent
{
    TicketCreated = 0,
    TicketAssigned = 1,
    TicketUpdated = 2,
    TicketResolved = 3,
    TicketClosed = 4,
    SlaBreached = 5
}
