using Microsoft.AspNetCore.Authorization;

namespace ITSM.API.Authorization;

public class RequirePermissionAttribute : AuthorizeAttribute
{
    public RequirePermissionAttribute(string permission) : base(policy: permission)
    {
    }
}
