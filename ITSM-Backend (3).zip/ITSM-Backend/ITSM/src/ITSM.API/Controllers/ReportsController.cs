using ITSM.Application.Common;
using ITSM.API.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ITSM.API.Controllers;

// NOTE: report.view permission exists in spec but no report data model/fields were defined.
[ApiController]
[Route("api/reports")]
[Authorize]
public class ReportsController : ControllerBase
{
    [RequirePermission(PermissionCodes.ReportView)]
    [HttpGet]
    public IActionResult GetReports()
    {
        return StatusCode(501, new { error = "Report data model not defined in spec. Cannot implement." });
    }
}
