using System.Security.Claims;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Notification;
using ITSM.Application.Interfaces;
using ITSM.API.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ITSM.API.Controllers;

[ApiController]
[Route("api/notifications")]
[Authorize]
public class NotificationsController : ControllerBase
{
    private readonly INotificationService _notificationService;

    public NotificationsController(INotificationService notificationService)
    {
        _notificationService = notificationService;
    }

    private Guid CurrentUserId => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    [RequirePermission(PermissionCodes.NotificationView)]
    [HttpGet]
    public async Task<ActionResult<List<NotificationDto>>> GetAll()
    {
        return Ok(await _notificationService.GetForUserAsync(CurrentUserId));
    }

    [RequirePermission(PermissionCodes.NotificationView)]
    [HttpPost("{id:guid}/mark-read")]
    public async Task<IActionResult> MarkAsRead(Guid id)
    {
        await _notificationService.MarkAsReadAsync(id, CurrentUserId);
        return NoContent();
    }
}
