using ITSM.Application.Common;
using ITSM.API.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ITSM.API.Controllers;

// NOTE: approval.approve permission exists in spec but no Approval entity/workflow was defined.
[ApiController]
[Route("api/approvals")]
[Authorize]
public class ApprovalsController : ControllerBase
{
    [RequirePermission(PermissionCodes.ApprovalApprove)]
    [HttpPost("{id:guid}/approve")]
    public IActionResult Approve(Guid id)
    {
        return StatusCode(501, new { error = "Approval entity/workflow not defined in spec. Cannot implement." });
    }
}
