using System.Security.Claims;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Ticket;
using ITSM.Application.Interfaces;
using ITSM.API.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ITSM.API.Controllers;

[ApiController]
[Route("api/tickets")]
[Authorize]
public class TicketsController : ControllerBase
{
    private readonly ITicketService _ticketService;
    private readonly ICurrentUserService _currentUserService;

    public TicketsController(ITicketService ticketService, ICurrentUserService currentUserService)
    {
        _ticketService = ticketService;
        _currentUserService = currentUserService;
    }

    private Guid CurrentUserId => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    private string CurrentRole => _currentUserService.Role ?? string.Empty;

    private Guid? CurrentDepartmentId => _currentUserService.DepartmentId;

    [RequirePermission(PermissionCodes.TicketView)]
    [HttpGet]
    public async Task<ActionResult<List<TicketDto>>> GetAll()
    {
        var result = await _ticketService.GetAllAsync(CurrentUserId, CurrentRole, CurrentDepartmentId);
        return Ok(result);
    }

    [RequirePermission(PermissionCodes.TicketView)]
    [HttpGet("{id:guid}")]
    public async Task<ActionResult<TicketDto>> GetById(Guid id)
    {
        var canAccess = await _ticketService.CanUserAccessTicketAsync(id, CurrentUserId, CurrentRole, CurrentDepartmentId);
        if (!canAccess) return Forbid();

        var ticket = await _ticketService.GetByIdAsync(id);
        if (ticket == null) return NotFound();
        return Ok(ticket);
    }

    [RequirePermission(PermissionCodes.TicketCreate)]
    [HttpPost]
    public async Task<ActionResult<TicketDto>> Create([FromBody] CreateTicketDto dto)
    {
        var result = await _ticketService.CreateAsync(dto, CurrentUserId);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [RequirePermission(PermissionCodes.TicketUpdate)]
    [HttpPut("{id:guid}")]
    public async Task<ActionResult<TicketDto>> Update(Guid id, [FromBody] UpdateTicketDto dto)
    {
        var canAccess = await _ticketService.CanUserAccessTicketAsync(id, CurrentUserId, CurrentRole, CurrentDepartmentId);
        if (!canAccess) return Forbid();

        var result = await _ticketService.UpdateAsync(id, dto, CurrentUserId);
        return Ok(result);
    }

    [RequirePermission(PermissionCodes.TicketTakeOwnership)]
    [HttpPost("{id:guid}/take-ownership")]
    public async Task<ActionResult<TicketDto>> TakeOwnership(Guid id)
    {
        var result = await _ticketService.TakeOwnershipAsync(id, CurrentUserId, CurrentRole, CurrentDepartmentId);
        return Ok(result);
    }

    [RequirePermission(PermissionCodes.TicketResolve)]
    [HttpPost("{id:guid}/resolve")]
    public async Task<ActionResult<TicketDto>> Resolve(Guid id)
    {
        var result = await _ticketService.ResolveAsync(id, CurrentUserId, CurrentRole, CurrentDepartmentId);
        return Ok(result);
    }

    [RequirePermission(PermissionCodes.TicketClose)]
    [HttpPost("{id:guid}/close")]
    public async Task<ActionResult<TicketDto>> Close(Guid id)
    {
        var result = await _ticketService.CloseAsync(id, CurrentUserId, CurrentRole, CurrentDepartmentId);
        return Ok(result);
    }

    // Covers PendingUser / PendingVendor / back-to-InProgress (reopen) / Cancelled transitions.
    [RequirePermission(PermissionCodes.TicketUpdate)]
    [HttpPost("{id:guid}/status")]
    public async Task<ActionResult<TicketDto>> ChangeStatus(Guid id, [FromBody] ChangeTicketStatusDto dto)
    {
        var result = await _ticketService.ChangeStatusAsync(id, dto.Status, CurrentUserId, CurrentRole, CurrentDepartmentId);
        return Ok(result);
    }
}
