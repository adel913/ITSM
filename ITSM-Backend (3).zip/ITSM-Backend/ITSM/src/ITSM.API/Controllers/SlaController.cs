using ITSM.Application.Common;
using ITSM.Application.DTOs.Sla;
using ITSM.Application.Interfaces;
using ITSM.Domain.Enums;
using ITSM.API.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ITSM.API.Controllers;

[ApiController]
[Route("api/sla-policies")]
[Authorize]
public class SlaController : ControllerBase
{
    private readonly ISlaService _slaService;

    public SlaController(ISlaService slaService)
    {
        _slaService = slaService;
    }

    [RequirePermission(PermissionCodes.SlaView)]
    [HttpGet]
    public async Task<ActionResult<List<SlaPolicyDto>>> GetAll()
    {
        return Ok(await _slaService.GetAllAsync());
    }

    [RequirePermission(PermissionCodes.SlaManage)]
    [HttpPut("{priority}")]
    public async Task<ActionResult<SlaPolicyDto>> Update(string priority, [FromBody] UpdateSlaPolicyDto dto)
    {
        if (!Enum.TryParse<TicketPriority>(priority, true, out var parsedPriority))
        {
            return BadRequest(new { error = "Invalid priority. Must be Low, Medium, High or Critical." });
        }

        var result = await _slaService.UpdateAsync(parsedPriority, dto);
        return Ok(result);
    }
}
