using ITSM.Application.DTOs.Category;
using ITSM.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ITSM.API.Controllers;

[ApiController]
[Route("api/ticket-categories")]
[Authorize]
public class TicketCategoriesController : ControllerBase
{
    private readonly ITicketCategoryService _categoryService;

    public TicketCategoriesController(ITicketCategoryService categoryService)
    {
        _categoryService = categoryService;
    }

    [HttpGet]
    public async Task<ActionResult<List<TicketCategoryDto>>> GetAll()
    {
        return Ok(await _categoryService.GetAllAsync());
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<TicketCategoryDto>> GetById(Guid id)
    {
        var category = await _categoryService.GetByIdAsync(id);
        if (category == null) return NotFound();
        return Ok(category);
    }

    // Category management is administrative; reuses ticket.update permission since the
    // spec's permission list has no dedicated category.create/update permission.
    [Authorize(Policy = "ticket.update")]
    [HttpPost]
    public async Task<ActionResult<TicketCategoryDto>> Create([FromBody] CreateTicketCategoryDto dto)
    {
        var result = await _categoryService.CreateAsync(dto);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [Authorize(Policy = "ticket.update")]
    [HttpPut("{id:guid}")]
    public async Task<ActionResult<TicketCategoryDto>> Update(Guid id, [FromBody] UpdateTicketCategoryDto dto)
    {
        var result = await _categoryService.UpdateAsync(id, dto);
        return Ok(result);
    }
}
