using System.Security.Claims;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Attachment;
using ITSM.Application.Interfaces;
using ITSM.API.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ITSM.API.Controllers;

[ApiController]
[Route("api/tickets/{ticketId:guid}/attachments")]
[Authorize]
public class TicketAttachmentsController : ControllerBase
{
    private readonly ITicketAttachmentService _attachmentService;
    private readonly ITicketService _ticketService;
    private readonly ICurrentUserService _currentUserService;

    public TicketAttachmentsController(
        ITicketAttachmentService attachmentService,
        ITicketService ticketService,
        ICurrentUserService currentUserService)
    {
        _attachmentService = attachmentService;
        _ticketService = ticketService;
        _currentUserService = currentUserService;
    }

    private Guid CurrentUserId => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    private string CurrentRole => _currentUserService.Role ?? string.Empty;

    private Guid? CurrentDepartmentId => _currentUserService.DepartmentId;

    [RequirePermission(PermissionCodes.TicketView)]
    [HttpGet]
    public async Task<ActionResult<List<TicketAttachmentDto>>> GetForTicket(Guid ticketId)
    {
        var canAccess = await _ticketService.CanUserAccessTicketAsync(ticketId, CurrentUserId, CurrentRole, CurrentDepartmentId);
        if (!canAccess) return Forbid();

        return Ok(await _attachmentService.GetForTicketAsync(ticketId));
    }

    [RequirePermission(PermissionCodes.TicketUpdate)]
    [HttpPost]
    [RequestSizeLimit(25 * 1024 * 1024)]
    public async Task<ActionResult<TicketAttachmentDto>> Upload(Guid ticketId, [FromForm] IFormFile file)
    {
        var canAccess = await _ticketService.CanUserAccessTicketAsync(ticketId, CurrentUserId, CurrentRole, CurrentDepartmentId);
        if (!canAccess) return Forbid();

        var result = await _attachmentService.UploadAsync(ticketId, file, CurrentUserId);
        return Ok(result);
    }

    [RequirePermission(PermissionCodes.TicketView)]
    [HttpGet("{attachmentId:guid}/download")]
    public async Task<IActionResult> Download(Guid ticketId, Guid attachmentId)
    {
        var canAccess = await _ticketService.CanUserAccessTicketAsync(ticketId, CurrentUserId, CurrentRole, CurrentDepartmentId);
        if (!canAccess) return Forbid();

        var (content, contentType, fileName) = await _attachmentService.DownloadAsync(ticketId, attachmentId);
        return File(content, contentType, fileName);
    }
}
