using System.Security.Claims;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Conversation;
using ITSM.Application.Interfaces;
using ITSM.API.Authorization;
using ITSM.API.Hubs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;

namespace ITSM.API.Controllers;

[ApiController]
[Route("api/tickets/{ticketId:guid}/conversation")]
[Authorize]
public class TicketConversationController : ControllerBase
{
    private readonly ITicketConversationService _conversationService;
    private readonly ICurrentUserService _currentUserService;
    private readonly IHubContext<TicketConversationHub> _hubContext;

    public TicketConversationController(
        ITicketConversationService conversationService,
        ICurrentUserService currentUserService,
        IHubContext<TicketConversationHub> hubContext)
    {
        _conversationService = conversationService;
        _currentUserService = currentUserService;
        _hubContext = hubContext;
    }

    private Guid CurrentUserId => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    private string CurrentRole => _currentUserService.Role ?? string.Empty;

    private Guid? CurrentDepartmentId => _currentUserService.DepartmentId;

    [RequirePermission(PermissionCodes.TicketChatView)]
    [HttpGet("messages")]
    public async Task<ActionResult<List<ConversationMessageDto>>> GetMessages(Guid ticketId)
    {
        var messages = await _conversationService.GetMessagesAsync(ticketId, CurrentUserId);
        return Ok(messages);
    }

    [RequirePermission(PermissionCodes.TicketChatSend)]
    [HttpPost("messages")]
    public async Task<ActionResult<ConversationMessageDto>> SendMessage(Guid ticketId, [FromBody] SendConversationMessageDto dto)
    {
        dto.TicketId = ticketId;
        var message = await _conversationService.SendMessageAsync(dto, CurrentUserId);
        await _hubContext.Clients.Group(ticketId.ToString()).SendAsync("ReceiveConversationMessage", message);
        return Ok(message);
    }
}
