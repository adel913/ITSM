using ITSM.Application.Common;
using ITSM.API.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ITSM.API.Controllers;

// NOTE: The spec defines asset.create and asset.update permissions but does not define
// the Asset entity's fields. Per the strict "no invented entities/fields" rule, no Asset
// persistence model has been created. These endpoints enforce permission checks only.
// Provide the Asset entity schema to implement full CRUD.
[ApiController]
[Route("api/assets")]
[Authorize]
public class AssetsController : ControllerBase
{
    [RequirePermission(PermissionCodes.AssetCreate)]
    [HttpPost]
    public IActionResult Create()
    {
        return StatusCode(501, new { error = "Asset entity schema not defined in spec. Cannot implement persistence." });
    }

    [RequirePermission(PermissionCodes.AssetUpdate)]
    [HttpPut("{id:guid}")]
    public IActionResult Update(Guid id)
    {
        return StatusCode(501, new { error = "Asset entity schema not defined in spec. Cannot implement persistence." });
    }
}
