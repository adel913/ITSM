using System.Security.Claims;
using ITSM.Application.Common;
using ITSM.Application.DTOs.User;
using ITSM.Application.Interfaces;
using ITSM.API.Authorization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ITSM.API.Controllers;

[ApiController]
[Route("api/users")]
[Authorize]
public class UsersController : ControllerBase
{
    private readonly IUserService _userService;
    private readonly ICurrentUserService _currentUserService;

    public UsersController(IUserService userService, ICurrentUserService currentUserService)
    {
        _userService = userService;
        _currentUserService = currentUserService;
    }

    private Guid CurrentUserId => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    private string CurrentRole => _currentUserService.Role ?? string.Empty;

    private Guid? CurrentDepartmentId => _currentUserService.DepartmentId;

    [HttpGet]
    public async Task<ActionResult<List<UserDto>>> GetAll()
    {
        return Ok(await _userService.GetAllAsync(CurrentUserId, CurrentRole, CurrentDepartmentId));
    }

    [HttpGet("{id:guid}")]
    public async Task<ActionResult<UserDto>> GetById(Guid id)
    {
        var user = await _userService.GetByIdAsync(id, CurrentUserId, CurrentRole, CurrentDepartmentId);
        if (user == null) return NotFound();
        return Ok(user);
    }

    [RequirePermission(PermissionCodes.UserCreate)]
    [HttpPost]
    public async Task<ActionResult<UserDto>> Create([FromBody] CreateUserDto dto)
    {
        var result = await _userService.CreateAsync(dto, CurrentUserId);
        return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
    }

    [RequirePermission(PermissionCodes.UserUpdate)]
    [HttpPut("{id:guid}")]
    public async Task<ActionResult<UserDto>> Update(Guid id, [FromBody] UpdateUserDto dto)
    {
        var result = await _userService.UpdateAsync(id, dto, CurrentUserId);
        return Ok(result);
    }

    [RequirePermission(PermissionCodes.UserDelete)]
    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Delete(Guid id)
    {
        await _userService.DeleteAsync(id, CurrentUserId);
        return NoContent();
    }
}
