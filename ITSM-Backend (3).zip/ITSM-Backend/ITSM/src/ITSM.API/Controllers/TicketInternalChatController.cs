using System.Security.Claims;
using ITSM.Application.Common;
using ITSM.Application.DTOs.InternalChat;
using ITSM.Application.Interfaces;
using ITSM.API.Authorization;
using ITSM.API.Hubs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;

namespace ITSM.API.Controllers;

[ApiController]
[Route("api/tickets/{ticketId:guid}/internal-chat")]
[Authorize]
public class TicketInternalChatController : ControllerBase
{
    private readonly ITicketInternalChatService _internalChatService;
    private readonly ITicketService _ticketService;
    private readonly IItUserDirectory _itUserDirectory;
    private readonly ICurrentUserService _currentUserService;
    private readonly IHubContext<TicketInternalChatHub> _hubContext;

    public TicketInternalChatController(
        ITicketInternalChatService internalChatService,
        ITicketService ticketService,
        IItUserDirectory itUserDirectory,
        ICurrentUserService currentUserService,
        IHubContext<TicketInternalChatHub> hubContext)
    {
        _internalChatService = internalChatService;
        _ticketService = ticketService;
        _itUserDirectory = itUserDirectory;
        _currentUserService = currentUserService;
        _hubContext = hubContext;
    }

    private Guid CurrentUserId => Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier)!);

    private string CurrentRole => _currentUserService.Role ?? string.Empty;

    private Guid? CurrentDepartmentId => _currentUserService.DepartmentId;

    private bool IsItUser => _itUserDirectory.IsItRole(User.FindFirstValue(ClaimTypes.Role));

    [RequirePermission(PermissionCodes.TicketChatView)]
    [HttpGet("messages")]
    public async Task<ActionResult<List<InternalMessageDto>>> GetMessages(Guid ticketId)
    {
        if (!IsItUser) return Forbid();

        var canAccess = await _ticketService.CanUserAccessTicketAsync(ticketId, CurrentUserId, CurrentRole, CurrentDepartmentId);
        if (!canAccess) return Forbid();

        var messages = await _internalChatService.GetMessagesAsync(ticketId);
        return Ok(messages);
    }

    [RequirePermission(PermissionCodes.TicketChatSend)]
    [HttpPost("messages")]
    public async Task<ActionResult<InternalMessageDto>> SendMessage(Guid ticketId, [FromBody] SendInternalMessageDto dto)
    {
        if (!IsItUser) return Forbid();

        var canAccess = await _ticketService.CanUserAccessTicketAsync(ticketId, CurrentUserId, CurrentRole, CurrentDepartmentId);
        if (!canAccess) return Forbid();

        dto.TicketId = ticketId;
        var message = await _internalChatService.SendMessageAsync(dto, CurrentUserId);
        await _hubContext.Clients.Group($"internal-{ticketId}").SendAsync("ReceiveInternalMessage", message);
        return Ok(message);
    }
}
