using System.Security.Claims;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Conversation;
using ITSM.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace ITSM.API.Hubs;

[Authorize]
public class TicketConversationHub : Hub
{
    private readonly ITicketConversationService _conversationService;
    private readonly ITicketService _ticketService;
    private readonly IItUserDirectory _itUserDirectory;

    public TicketConversationHub(
        ITicketConversationService conversationService,
        ITicketService ticketService,
        IItUserDirectory itUserDirectory)
    {
        _conversationService = conversationService;
        _ticketService = ticketService;
        _itUserDirectory = itUserDirectory;
    }

    private Guid GetUserId() => Guid.Parse(Context.User!.FindFirst(ClaimTypes.NameIdentifier)!.Value);

    private bool HasPermission(string permission) =>
        Context.User?.Claims.Any(c => c.Type == "permission" && c.Value == permission) ?? false;

    public async Task JoinTicketGroup(Guid ticketId)
    {
        if (!HasPermission(PermissionCodes.TicketChatView))
        {
            throw new HubException("You do not have permission to view this conversation.");
        }

        var userId = GetUserId();
        var canAccess = await _ticketService.IsCreatorOrAssignedTechnicianAsync(ticketId, userId);
        if (!canAccess)
        {
            throw new HubException("You do not have access to this ticket's conversation.");
        }

        await Groups.AddToGroupAsync(Context.ConnectionId, ticketId.ToString());
    }

    public async Task LeaveTicketGroup(Guid ticketId)
    {
        await Groups.RemoveFromGroupAsync(Context.ConnectionId, ticketId.ToString());
    }

    public async Task SendMessage(SendConversationMessageDto dto)
    {
        if (!HasPermission(PermissionCodes.TicketChatSend))
        {
            throw new HubException("You do not have permission to send messages.");
        }

        var userId = GetUserId();
        var message = await _conversationService.SendMessageAsync(dto, userId);

        await Clients.Group(dto.TicketId.ToString()).SendAsync("ReceiveConversationMessage", message);
    }
}
