using System.Security.Claims;
using ITSM.Application.Common;
using ITSM.Application.DTOs.InternalChat;
using ITSM.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;

namespace ITSM.API.Hubs;

[Authorize]
public class TicketInternalChatHub : Hub
{
    private readonly ITicketInternalChatService _internalChatService;
    private readonly ITicketService _ticketService;
    private readonly IItUserDirectory _itUserDirectory;
    private readonly ICurrentUserService _currentUserService;

    public TicketInternalChatHub(
        ITicketInternalChatService internalChatService,
        ITicketService ticketService,
        IItUserDirectory itUserDirectory,
        ICurrentUserService currentUserService)
    {
        _internalChatService = internalChatService;
        _ticketService = ticketService;
        _itUserDirectory = itUserDirectory;
        _currentUserService = currentUserService;
    }

    private Guid GetUserId() => Guid.Parse(Context.User!.FindFirst(ClaimTypes.NameIdentifier)!.Value);

    private string GetRole() => _currentUserService.Role ?? string.Empty;

    private Guid? GetDepartmentId() => _currentUserService.DepartmentId;

    private bool IsItUser() => _itUserDirectory.IsItRole(Context.User?.FindFirst(ClaimTypes.Role)?.Value);

    private bool HasPermission(string permission) =>
        Context.User?.Claims.Any(c => c.Type == "permission" && c.Value == permission) ?? false;

    public async Task JoinTicketGroup(Guid ticketId)
    {
        if (!HasPermission(PermissionCodes.TicketChatView) || !IsItUser())
        {
            throw new HubException("Internal IT conversation is restricted to IT Department users.");
        }

        var userId = GetUserId();
        var canAccess = await _ticketService.CanUserAccessTicketAsync(ticketId, userId, GetRole(), GetDepartmentId());
        if (!canAccess)
        {
            throw new HubException("You do not have access to this ticket's internal chat.");
        }

        await Groups.AddToGroupAsync(Context.ConnectionId, $"internal-{ticketId}");
    }

    public async Task LeaveTicketGroup(Guid ticketId)
    {
        await Groups.RemoveFromGroupAsync(Context.ConnectionId, $"internal-{ticketId}");
    }

    public async Task SendMessage(SendInternalMessageDto dto)
    {
        if (!HasPermission(PermissionCodes.TicketChatSend) || !IsItUser())
        {
            throw new HubException("Internal IT conversation is restricted to IT Department users.");
        }

        var userId = GetUserId();
        var canAccess = await _ticketService.CanUserAccessTicketAsync(dto.TicketId, userId, GetRole(), GetDepartmentId());
        if (!canAccess)
        {
            throw new HubException("You do not have access to this ticket's internal chat.");
        }

        var message = await _internalChatService.SendMessageAsync(dto, userId);

        await Clients.Group($"internal-{dto.TicketId}").SendAsync("ReceiveInternalMessage", message);
    }
}
