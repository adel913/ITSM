using System.Net;
using System.Text.Json;
using ITSM.Application.Common;
using Microsoft.EntityFrameworkCore;
using Serilog;

namespace ITSM.API.Middleware;

public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;

    public ExceptionHandlingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (AppException ex)
        {
            // Covers BusinessException (400), NotFoundException (404), ForbiddenException (403),
            // UnauthorizedAppException (401), ConcurrencyException (409), and the base AppException (400).
            Log.Warning(ex, "Handled application exception: {Message}", ex.Message);
            await WriteResponseAsync(context, ex.StatusCode, ex.Message);
        }
        catch (UnauthorizedAccessException ex)
        {
            Log.Warning(ex, "Unauthorized access attempt: {Message}", ex.Message);
            await WriteResponseAsync(context, (int)HttpStatusCode.Unauthorized, "Unauthorized.");
        }
        catch (DbUpdateConcurrencyException ex)
        {
            Log.Warning(ex, "Concurrency conflict detected.");
            await WriteResponseAsync(context, (int)HttpStatusCode.Conflict, "This record has been modified by another user. Please reload and try again.");
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Unhandled exception occurred.");
            await WriteResponseAsync(context, (int)HttpStatusCode.InternalServerError, "An unexpected error occurred.");
        }
    }

    private static async Task WriteResponseAsync(HttpContext context, int statusCode, string message)
    {
        context.Response.ContentType = "application/json";
        context.Response.StatusCode = statusCode;

        var payload = JsonSerializer.Serialize(new
        {
            success = false,
            message,
            statusCode
        });

        await context.Response.WriteAsync(payload);
    }
}
