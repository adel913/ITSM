using AutoMapper;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Category;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Services;

public class TicketCategoryService : ITicketCategoryService
{
    private readonly ITSMDbContext _context;
    private readonly IMapper _mapper;

    public TicketCategoryService(ITSMDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<List<TicketCategoryDto>> GetAllAsync()
    {
        var categories = await _context.TicketCategories.ToListAsync();
        return _mapper.Map<List<TicketCategoryDto>>(categories);
    }

    public async Task<TicketCategoryDto?> GetByIdAsync(Guid id)
    {
        var category = await _context.TicketCategories.FirstOrDefaultAsync(c => c.Id == id);
        return category == null ? null : _mapper.Map<TicketCategoryDto>(category);
    }

    public async Task<TicketCategoryDto> CreateAsync(CreateTicketCategoryDto dto)
    {
        if (await _context.TicketCategories.AnyAsync(c => c.Name == dto.Name))
        {
            throw new AppException("A category with this name already exists.");
        }

        var category = new TicketCategory
        {
            Name = dto.Name,
            Description = dto.Description,
            IsActive = true
        };

        _context.TicketCategories.Add(category);
        await _context.SaveChangesAsync();

        return _mapper.Map<TicketCategoryDto>(category);
    }

    public async Task<TicketCategoryDto> UpdateAsync(Guid id, UpdateTicketCategoryDto dto)
    {
        var category = await _context.TicketCategories.FirstOrDefaultAsync(c => c.Id == id);
        if (category == null)
        {
            throw new NotFoundException("Category not found.");
        }

        category.Name = dto.Name;
        category.Description = dto.Description;
        category.IsActive = dto.IsActive;

        await _context.SaveChangesAsync();

        return _mapper.Map<TicketCategoryDto>(category);
    }
}
