using AutoMapper;
using ITSM.Application.Common;
using ITSM.Application.DTOs.User;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Domain.Enums;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Services;

public class UserService : IUserService
{
    private readonly ITSMDbContext _context;
    private readonly IMapper _mapper;
    private readonly IPasswordHasher _passwordHasher;
    private readonly IAuditService _auditService;

    public UserService(ITSMDbContext context, IMapper mapper, IPasswordHasher passwordHasher, IAuditService auditService)
    {
        _context = context;
        _mapper = mapper;
        _passwordHasher = passwordHasher;
        _auditService = auditService;
    }

    public async Task<List<UserDto>> GetAllAsync(Guid currentUserId, string role, Guid? departmentId)
    {
        IQueryable<User> query = _context.Users
            .Include(u => u.Department)
            .Include(u => u.Role);

        if (role == RoleNames.Admin)
        {
            // no filter
        }
        else if (role == RoleNames.ITManager && departmentId.HasValue)
        {
            query = query.Where(u => u.DepartmentId == departmentId.Value);
        }
        else
        {
            query = query.Where(u => u.Id == currentUserId);
        }

        var users = await query.ToListAsync();
        return _mapper.Map<List<UserDto>>(users);
    }

    public async Task<UserDto?> GetByIdAsync(Guid id, Guid currentUserId, string role, Guid? departmentId)
    {
        var user = await _context.Users
            .Include(u => u.Department)
            .Include(u => u.Role)
            .FirstOrDefaultAsync(u => u.Id == id);

        if (user == null) return null;

        if (role == RoleNames.Admin)
        {
            return _mapper.Map<UserDto>(user);
        }

        if (role == RoleNames.ITManager && departmentId.HasValue && user.DepartmentId == departmentId.Value)
        {
            return _mapper.Map<UserDto>(user);
        }

        if (user.Id == currentUserId)
        {
            return _mapper.Map<UserDto>(user);
        }

        return null;
    }

    public async Task<UserDto> CreateAsync(CreateUserDto dto, Guid actingUserId)
    {
        var actingUser = await _context.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == actingUserId);
        if (actingUser == null || (actingUser.Role.Name != RoleNames.Admin && actingUser.Role.Name != RoleNames.ITManager))
        {
            throw new ForbiddenException("Only Admin and IT Manager can create users.");
        }

        var department = await _context.Departments.FirstOrDefaultAsync(d => d.Id == dto.DepartmentId);
        if (department == null)
        {
            throw new NotFoundException("Department not found.");
        }

        var role = await _context.Roles.FirstOrDefaultAsync(r => r.Id == dto.RoleId);
        if (role == null)
        {
            throw new NotFoundException("Role not found.");
        }

        if (await _context.Users.AnyAsync(u => u.Email == dto.Email))
        {
            throw new AppException("Email already exists.");
        }

        if (await _context.Users.AnyAsync(u => u.EmployeeCode == dto.EmployeeCode))
        {
            throw new AppException("Employee code already exists.");
        }

        var user = new User
        {
            EmployeeCode = dto.EmployeeCode,
            FullName = dto.FullName,
            Email = dto.Email,
            Phone = dto.Phone,
            PasswordHash = _passwordHasher.Hash(dto.Password),
            DepartmentId = dto.DepartmentId,
            RoleId = dto.RoleId,
            UserStatus = UserStatus.Active,
            IsDeleted = false
        };

        _context.Users.Add(user);
        await _context.SaveChangesAsync();

        await _auditService.LogAsync(actingUserId, "UserCreated", $"User {user.Email} created.", entityType: "User", entityId: user.Id.ToString());

        return (await GetByIdAsync(user.Id, actingUserId, actingUser.Role.Name, actingUser.DepartmentId))!;
    }

    public async Task<UserDto> UpdateAsync(Guid id, UpdateUserDto dto, Guid actingUserId)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == id);
        if (user == null)
        {
            throw new NotFoundException("User not found.");
        }

        var department = await _context.Departments.FirstOrDefaultAsync(d => d.Id == dto.DepartmentId);
        if (department == null)
        {
            throw new NotFoundException("Department not found.");
        }

        var role = await _context.Roles.FirstOrDefaultAsync(r => r.Id == dto.RoleId);
        if (role == null)
        {
            throw new NotFoundException("Role not found.");
        }

        if (!Enum.TryParse<UserStatus>(dto.UserStatus, out var status))
        {
            throw new AppException("Invalid UserStatus.");
        }

        user.FullName = dto.FullName;
        user.Email = dto.Email;
        user.Phone = dto.Phone;
        user.DepartmentId = dto.DepartmentId;
        var previousRoleId = user.RoleId;
        user.RoleId = dto.RoleId;
        var previousStatus = user.UserStatus;
        user.UserStatus = status;

        await _context.SaveChangesAsync();

        // Hardening item 8: a deactivated/suspended user's existing refresh tokens must not
        // remain usable. Previously nothing revoked them, so a token issued before
        // deactivation stayed valid (and kept renewing access tokens) until its own
        // expiration, regardless of UserStatus. This closes that gap without touching
        // Notifications (cascade-deleted with the user already; no orphan risk while the
        // account is merely deactivated rather than deleted).
        if (previousStatus == UserStatus.Active && status != UserStatus.Active)
        {
            var activeTokens = await _context.RefreshTokens
                .Where(t => t.UserId == user.Id && t.RevokedAtUtc == null)
                .ToListAsync();

            foreach (var token in activeTokens)
            {
                token.RevokedAtUtc = DateTime.UtcNow;
            }

            await _context.SaveChangesAsync();
        }

        await _auditService.LogAsync(actingUserId, "UserUpdated", $"User {user.Email} updated.", entityType: "User", entityId: user.Id.ToString());

        if (previousRoleId != dto.RoleId)
        {
            var previousRole = await _context.Roles.FirstOrDefaultAsync(r => r.Id == previousRoleId);
            await _auditService.LogAsync(
                actingUserId,
                "RoleChanged",
                $"User {user.Email} role changed from {previousRole?.Name ?? previousRoleId.ToString()} to {role.Name}.",
                entityType: "User",
                entityId: user.Id.ToString());
        }

        var actingUser = await _context.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == actingUserId);
        return (await GetByIdAsync(user.Id, actingUserId, actingUser?.Role.Name ?? RoleNames.Admin, actingUser?.DepartmentId))!;
    }

    public async Task DeleteAsync(Guid id, Guid actingUserId)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Id == id);
        if (user == null)
        {
            throw new NotFoundException("User not found.");
        }

        user.IsDeleted = true;

        // Hardening item 8: revoke all active refresh tokens/sessions on (soft) delete so
        // a deleted user's existing tokens can't keep refreshing access tokens. Notification
        // rows are left in place (cascade-deleted only if the User row is ever hard-deleted),
        // which is correct: they're historical records, not active sessions, so they don't
        // constitute an orphan/security risk.
        var activeTokens = await _context.RefreshTokens
            .Where(t => t.UserId == user.Id && t.RevokedAtUtc == null)
            .ToListAsync();

        foreach (var token in activeTokens)
        {
            token.RevokedAtUtc = DateTime.UtcNow;
        }

        await _context.SaveChangesAsync();

        await _auditService.LogAsync(actingUserId, "UserDeleted", $"User {user.Email} soft-deleted.", entityType: "User", entityId: user.Id.ToString());
    }
}
