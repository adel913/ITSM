using AutoMapper;
using ITSM.Application.DTOs.Notification;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Domain.Enums;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Services;

public class NotificationService : INotificationService
{
    private readonly ITSMDbContext _context;
    private readonly IMapper _mapper;

    public NotificationService(ITSMDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public async Task<List<NotificationDto>> GetForUserAsync(Guid userId)
    {
        var notifications = await _context.Notifications
            .Where(n => n.UserId == userId)
            .OrderByDescending(n => n.CreatedAt)
            .ToListAsync();

        return _mapper.Map<List<NotificationDto>>(notifications);
    }

    public async Task MarkAsReadAsync(Guid notificationId, Guid userId)
    {
        var notification = await _context.Notifications
            .FirstOrDefaultAsync(n => n.Id == notificationId && n.UserId == userId);

        if (notification == null) return;

        notification.IsRead = true;
        await _context.SaveChangesAsync();
    }

    public async Task NotifyUserAsync(Guid userId, NotificationEvent eventType, string title, string message)
    {
        _context.Notifications.Add(new Notification
        {
            UserId = userId,
            Title = title,
            Message = message,
            IsRead = false
        });

        await _context.SaveChangesAsync();
    }

    public async Task NotifyUsersAsync(IEnumerable<Guid> userIds, NotificationEvent eventType, string title, string message)
    {
        foreach (var userId in userIds)
        {
            _context.Notifications.Add(new Notification
            {
                UserId = userId,
                Title = title,
                Message = message,
                IsRead = false
            });
        }

        await _context.SaveChangesAsync();
    }
}
