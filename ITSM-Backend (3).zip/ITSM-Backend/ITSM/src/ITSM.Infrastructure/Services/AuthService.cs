using ITSM.Application.Common;
using ITSM.Application.DTOs.Auth;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Domain.Enums;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Services;

public class AuthService : IAuthService
{
    private readonly ITSMDbContext _context;
    private readonly IPasswordHasher _passwordHasher;
    private readonly IJwtTokenService _jwtTokenService;
    private readonly IAuditService _auditService;
    private readonly ICurrentUserService _currentUserService;

    private const int MaxFailedAttempts = 5;
    private const int LockoutMinutes = 15;
    private const int RefreshTokenExpirationDays = 7;

    public AuthService(
        ITSMDbContext context,
        IPasswordHasher passwordHasher,
        IJwtTokenService jwtTokenService,
        IAuditService auditService,
        ICurrentUserService currentUserService)
    {
        _context = context;
        _passwordHasher = passwordHasher;
        _jwtTokenService = jwtTokenService;
        _auditService = auditService;
        _currentUserService = currentUserService;
    }

    private async Task<List<string>> GetPermissionsForRoleAsync(Guid roleId)
    {
        return await _context.RolePermissions
            .Where(rp => rp.RoleId == roleId)
            .Select(rp => rp.Permission.Module + "." + rp.Permission.Action)
            .ToListAsync();
    }

    public async Task<LoginResponseDto> LoginAsync(LoginRequestDto request)
    {
        var user = await _context.Users
            .Include(u => u.Role)
            .Include(u => u.Department)
            .FirstOrDefaultAsync(u => u.Email == request.Email);

        if (user == null)
        {
            throw new UnauthorizedAppException("Invalid email or password.");
        }

        if (user.LockoutEndUtc.HasValue && user.LockoutEndUtc.Value > DateTime.UtcNow)
        {
            throw new UnauthorizedAppException($"Account locked. Try again after {user.LockoutEndUtc.Value:O}.");
        }

        if (user.UserStatus != UserStatus.Active)
        {
            throw new UnauthorizedAppException("User account is not active.");
        }

        if (!_passwordHasher.Verify(request.Password, user.PasswordHash))
        {
            user.FailedLoginAttempts += 1;
            if (user.FailedLoginAttempts >= MaxFailedAttempts)
            {
                user.LockoutEndUtc = DateTime.UtcNow.AddMinutes(LockoutMinutes);
                user.FailedLoginAttempts = 0;
            }
            await _context.SaveChangesAsync();
            throw new UnauthorizedAppException("Invalid email or password.");
        }

        user.FailedLoginAttempts = 0;
        user.LockoutEndUtc = null;

        var permissions = await GetPermissionsForRoleAsync(user.RoleId);

        var (accessToken, expiresAtUtc) = _jwtTokenService.GenerateAccessToken(user, permissions);
        var refreshTokenValue = _jwtTokenService.GenerateRefreshToken();

        var refreshToken = new RefreshToken
        {
            Token = refreshTokenValue,
            UserId = user.Id,
            ExpiresAtUtc = DateTime.UtcNow.AddDays(RefreshTokenExpirationDays),
            DeviceInfo = request.DeviceInfo
        };

        _context.RefreshTokens.Add(refreshToken);
        await _context.SaveChangesAsync();

        await _auditService.LogAsync(user.Id, "Login", $"User {user.Email} logged in.", _currentUserService.IpAddress);

        return new LoginResponseDto
        {
            AccessToken = accessToken,
            RefreshToken = refreshTokenValue,
            AccessTokenExpiresAtUtc = expiresAtUtc,
            UserId = user.Id,
            FullName = user.FullName,
            Role = user.Role.Name,
            Permissions = permissions
        };
    }

    public async Task LogoutAsync(LogoutRequestDto request)
    {
        var token = await _context.RefreshTokens.FirstOrDefaultAsync(t => t.Token == request.RefreshToken);
        if (token == null)
        {
            throw new NotFoundException("Refresh token not found.");
        }

        token.RevokedAtUtc = DateTime.UtcNow;
        await _context.SaveChangesAsync();

        await _auditService.LogAsync(token.UserId, "Logout", "User logged out.", _currentUserService.IpAddress);
    }

    public async Task<LoginResponseDto> RefreshTokenAsync(RefreshTokenRequestDto request)
    {
        var existingToken = await _context.RefreshTokens
            .Include(t => t.User).ThenInclude(u => u.Role)
            .Include(t => t.User).ThenInclude(u => u.Department)
            .FirstOrDefaultAsync(t => t.Token == request.RefreshToken);

        if (existingToken == null || !existingToken.IsActive)
        {
            throw new UnauthorizedAppException("Invalid or expired refresh token.");
        }

        var user = existingToken.User;

        if (user.UserStatus != UserStatus.Active)
        {
            throw new UnauthorizedAppException("User account is not active.");
        }

        var permissions = await GetPermissionsForRoleAsync(user.RoleId);
        var (accessToken, expiresAtUtc) = _jwtTokenService.GenerateAccessToken(user, permissions);
        var newRefreshTokenValue = _jwtTokenService.GenerateRefreshToken();

        existingToken.RevokedAtUtc = DateTime.UtcNow;
        existingToken.ReplacedByToken = newRefreshTokenValue;

        var newRefreshToken = new RefreshToken
        {
            Token = newRefreshTokenValue,
            UserId = user.Id,
            ExpiresAtUtc = DateTime.UtcNow.AddDays(RefreshTokenExpirationDays),
            DeviceInfo = existingToken.DeviceInfo
        };

        _context.RefreshTokens.Add(newRefreshToken);
        await _context.SaveChangesAsync();

        return new LoginResponseDto
        {
            AccessToken = accessToken,
            RefreshToken = newRefreshTokenValue,
            AccessTokenExpiresAtUtc = expiresAtUtc,
            UserId = user.Id,
            FullName = user.FullName,
            Role = user.Role.Name,
            Permissions = permissions
        };
    }

    public async Task ForgotPasswordAsync(ForgotPasswordRequestDto request)
    {
        var user = await _context.Users.FirstOrDefaultAsync(u => u.Email == request.Email);
        if (user == null)
        {
            // Do not reveal whether the email exists.
            return;
        }

        user.PasswordResetToken = Guid.NewGuid().ToString("N");
        user.PasswordResetTokenExpiresAtUtc = DateTime.UtcNow.AddHours(1);
        await _context.SaveChangesAsync();

        await _auditService.LogAsync(user.Id, "PasswordResetRequested", $"Forgot password requested for {user.Email}.", _currentUserService.IpAddress);
    }

    public async Task ResetPasswordAsync(ResetPasswordRequestDto request, Guid adminUserId)
    {
        var admin = await _context.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == adminUserId);
        if (admin == null || admin.Role.Name != RoleNames.Admin)
        {
            throw new ForbiddenException("Only Admin can reset passwords.");
        }

        var targetUser = await _context.Users.FirstOrDefaultAsync(u => u.Id == request.TargetUserId);
        if (targetUser == null)
        {
            throw new NotFoundException("Target user not found.");
        }

        targetUser.PasswordHash = _passwordHasher.Hash(request.NewPassword);
        targetUser.PasswordResetToken = null;
        targetUser.PasswordResetTokenExpiresAtUtc = null;
        targetUser.FailedLoginAttempts = 0;
        targetUser.LockoutEndUtc = null;

        await _context.SaveChangesAsync();

        await _auditService.LogAsync(adminUserId, "PasswordReset", $"Admin reset password for user {targetUser.Email}.", _currentUserService.IpAddress);
    }

    public async Task ChangePasswordAsync(ChangePasswordRequestDto request, Guid adminUserId)
    {
        var admin = await _context.Users.Include(u => u.Role).FirstOrDefaultAsync(u => u.Id == adminUserId);
        if (admin == null || admin.Role.Name != RoleNames.Admin)
        {
            throw new ForbiddenException("Only Admin can change/reset a user's password.");
        }

        var targetUser = await _context.Users.FirstOrDefaultAsync(u => u.Id == request.TargetUserId);
        if (targetUser == null)
        {
            throw new NotFoundException("Target user not found.");
        }

        targetUser.PasswordHash = _passwordHasher.Hash(request.NewPassword);
        await _context.SaveChangesAsync();

        await _auditService.LogAsync(adminUserId, "PasswordChanged", $"Admin changed password for user {targetUser.Email}.", _currentUserService.IpAddress);
    }
}
