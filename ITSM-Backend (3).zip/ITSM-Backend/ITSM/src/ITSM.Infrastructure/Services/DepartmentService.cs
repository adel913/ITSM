using AutoMapper;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Department;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Domain.Enums;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Services;

public class DepartmentService : IDepartmentService
{
    private readonly ITSMDbContext _context;
    private readonly IMapper _mapper;
    private readonly IAuditService _auditService;

    public DepartmentService(ITSMDbContext context, IMapper mapper, IAuditService auditService)
    {
        _context = context;
        _mapper = mapper;
        _auditService = auditService;
    }

    public async Task<List<DepartmentDto>> GetAllAsync()
    {
        var departments = await _context.Departments.Include(d => d.Manager).ToListAsync();
        return _mapper.Map<List<DepartmentDto>>(departments);
    }

    public async Task<DepartmentDto?> GetByIdAsync(Guid id)
    {
        var department = await _context.Departments.Include(d => d.Manager).FirstOrDefaultAsync(d => d.Id == id);
        return department == null ? null : _mapper.Map<DepartmentDto>(department);
    }

    public async Task<DepartmentDto> CreateAsync(CreateDepartmentDto dto, Guid actingUserId)
    {
        if (dto.ManagerId.HasValue)
        {
            var manager = await _context.Users.FirstOrDefaultAsync(u => u.Id == dto.ManagerId.Value);
            if (manager == null || manager.UserStatus != UserStatus.Active)
            {
                throw new NotFoundException("Manager user not found or inactive.");
            }
        }

        var department = new Department
        {
            Name = dto.Name,
            Description = dto.Description,
            ManagerId = dto.ManagerId,
            IsActive = true
        };

        _context.Departments.Add(department);
        await _context.SaveChangesAsync();

        await _auditService.LogAsync(actingUserId, "DepartmentCreated", $"Department {department.Name} created.", entityType: "Department", entityId: department.Id.ToString());

        return (await GetByIdAsync(department.Id))!;
    }

    public async Task<DepartmentDto> UpdateAsync(Guid id, UpdateDepartmentDto dto, Guid actingUserId)
    {
        var department = await _context.Departments.FirstOrDefaultAsync(d => d.Id == id);
        if (department == null)
        {
            throw new NotFoundException("Department not found.");
        }

        if (dto.ManagerId.HasValue)
        {
            var manager = await _context.Users.FirstOrDefaultAsync(u => u.Id == dto.ManagerId.Value);
            if (manager == null || manager.UserStatus != UserStatus.Active)
            {
                throw new NotFoundException("Manager user not found or inactive.");
            }
        }

        department.Name = dto.Name;
        department.Description = dto.Description;
        department.ManagerId = dto.ManagerId;
        department.IsActive = dto.IsActive;

        await _context.SaveChangesAsync();

        await _auditService.LogAsync(actingUserId, "DepartmentUpdated", $"Department {department.Name} updated.", entityType: "Department", entityId: department.Id.ToString());

        return (await GetByIdAsync(department.Id))!;
    }

    public async Task DeleteAsync(Guid id, Guid actingUserId)
    {
        var department = await _context.Departments.FirstOrDefaultAsync(d => d.Id == id);
        if (department == null)
        {
            throw new NotFoundException("Department not found.");
        }

        var hasUsers = await _context.Users.AnyAsync(u => u.DepartmentId == id);
        if (hasUsers)
        {
            throw new AppException("Department cannot be deleted because users exist in it.");
        }

        // Hardening item 15: soft delete instead of physical removal, consistent with User.
        // Avoids breaking historical Ticket.DepartmentId references and keeps the row
        // available for audit/history purposes.
        department.IsDeleted = true;
        department.IsActive = false;
        await _context.SaveChangesAsync();

        await _auditService.LogAsync(actingUserId, "DepartmentDeleted", $"Department {department.Name} soft-deleted.", entityType: "Department", entityId: department.Id.ToString());
    }
}
