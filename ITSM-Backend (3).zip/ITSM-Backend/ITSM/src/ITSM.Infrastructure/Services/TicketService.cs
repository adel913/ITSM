using AutoMapper;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Ticket;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Domain.Enums;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Services;

public class TicketService : ITicketService
{
    private readonly ITSMDbContext _context;
    private readonly IMapper _mapper;
    private readonly IAuditService _auditService;
    private readonly ISlaService _slaService;
    private readonly INotificationService _notificationService;
    private readonly IEmailService _emailService;
    private readonly IItUserDirectory _itUserDirectory;

    // Roles treated as "Agent"/"Manager" in the hardening spec's department-isolation and
    // assignment-validation rules. Mapped onto the existing role names (no roles renamed).
    private static readonly string[] AssignableRoles = { RoleNames.Technician, RoleNames.ITManager };

    private static bool CanPerformAgentAction(Ticket ticket, Guid actingUserId, string role, Guid? departmentId)
    {
        if (ticket.AssignedToId == actingUserId) return true;
        if (role == RoleNames.Admin) return true;
        if (role == RoleNames.ITManager && departmentId.HasValue && ticket.DepartmentId == departmentId.Value) return true;
        return false;
    }

    public TicketService(
        ITSMDbContext context,
        IMapper mapper,
        IAuditService auditService,
        ISlaService slaService,
        INotificationService notificationService,
        IEmailService emailService,
        IItUserDirectory itUserDirectory)
    {
        _context = context;
        _mapper = mapper;
        _auditService = auditService;
        _slaService = slaService;
        _notificationService = notificationService;
        _emailService = emailService;
        _itUserDirectory = itUserDirectory;
    }

    private IQueryable<Ticket> BaseQuery() =>
        _context.Tickets
            .Include(t => t.Category)
            .Include(t => t.CreatedBy)
            .Include(t => t.AssignedTo)
            .Include(t => t.Department);

    private static async Task SaveChangesWithConcurrencyCheckAsync(ITSMDbContext context)
    {
        try
        {
            await context.SaveChangesAsync();
        }
        catch (DbUpdateConcurrencyException)
        {
            // Hardening item 11: friendly business error instead of leaking the raw EF exception.
            throw new ConcurrencyException("Ticket has been modified by another user.");
        }
    }

    public async Task<List<TicketDto>> GetAllAsync(Guid currentUserId, string role, Guid? departmentId)
    {
        IQueryable<Ticket> query = BaseQuery();

        // Hardening item 3 (department isolation):
        // - Admin: sees all tickets (unchanged from previous behavior for this role).
        // - Technician / IT Manager ("Agent"/"Manager"): scoped to their own department.
        // - Everyone else (Employee): only tickets they created.
        if (role == RoleNames.Admin)
        {
            // no filter
        }
        else if (AssignableRoles.Contains(role) && departmentId.HasValue)
        {
            query = query.Where(t => t.DepartmentId == departmentId.Value);
        }
        else
        {
            query = query.Where(t => t.CreatedById == currentUserId);
        }

        var tickets = await query.OrderByDescending(t => t.CreatedAt).ToListAsync();
        return _mapper.Map<List<TicketDto>>(tickets);
    }

    public async Task<TicketDto?> GetByIdAsync(Guid id)
    {
        var ticket = await BaseQuery().FirstOrDefaultAsync(t => t.Id == id);
        return ticket == null ? null : _mapper.Map<TicketDto>(ticket);
    }

    private static string GenerateTicketNumber()
    {
        return $"TCK-{DateTime.UtcNow:yyyyMMdd}-{Guid.NewGuid().ToString("N")[..6].ToUpperInvariant()}";
    }

    public async Task<TicketDto> CreateAsync(CreateTicketDto dto, Guid creatorUserId)
    {
        var creator = await _context.Users.FirstOrDefaultAsync(u => u.Id == creatorUserId);
        if (creator == null)
        {
            throw new NotFoundException("Creating user not found.");
        }

        var category = await _context.TicketCategories.FirstOrDefaultAsync(c => c.Id == dto.CategoryId && c.IsActive);
        if (category == null)
        {
            throw new NotFoundException("Ticket category not found or inactive.");
        }

        if (!Enum.TryParse<TicketPriority>(dto.Priority, out var priority))
        {
            throw new AppException("Invalid priority.");
        }

        var now = DateTime.UtcNow;
        var (responseDueAt, resolutionDueAt) = await _slaService.CalculateDueDatesAsync(priority, now);

        var ticket = new Ticket
        {
            TicketNumber = GenerateTicketNumber(),
            Title = dto.Title,
            Description = dto.Description,
            CategoryId = dto.CategoryId,
            CreatedById = creatorUserId,
            // Hardening item 3: snapshot creator's department onto the ticket so visibility
            // can be filtered by department without changing CreateTicketDto's contract.
            DepartmentId = creator.DepartmentId,
            AssignedToId = null,
            Status = TicketStatus.New,
            Priority = priority,
            ResponseDueAt = responseDueAt,
            ResolutionDueAt = resolutionDueAt
        };

        _context.Tickets.Add(ticket);
        await _context.SaveChangesAsync();

        await _auditService.LogAsync(creatorUserId, "TicketCreated", $"Ticket {ticket.TicketNumber} created.", entityType: "Ticket", entityId: ticket.Id.ToString());

        var itUserIds = await _itUserDirectory.GetItUserIdsAsync();
        await _notificationService.NotifyUsersAsync(
            itUserIds,
            NotificationEvent.TicketCreated,
            "New Ticket Created",
            $"Ticket {ticket.TicketNumber} - \"{ticket.Title}\" has been created and is awaiting assignment.");

        var itEmails = await _itUserDirectory.GetItUserEmailsAsync();
        await _emailService.SendEmailToManyAsync(
            itEmails,
            $"New Ticket Created: {ticket.TicketNumber}",
            $"A new ticket \"{ticket.Title}\" (Priority: {ticket.Priority}) has been created and needs assignment.");

        return (await GetByIdAsync(ticket.Id))!;
    }

    public async Task<TicketDto> UpdateAsync(Guid id, UpdateTicketDto dto, Guid actingUserId)
    {
        var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.Id == id);
        if (ticket == null)
        {
            throw new NotFoundException("Ticket not found.");
        }

        var category = await _context.TicketCategories.FirstOrDefaultAsync(c => c.Id == dto.CategoryId && c.IsActive);
        if (category == null)
        {
            throw new NotFoundException("Ticket category not found or inactive.");
        }

        if (!Enum.TryParse<TicketPriority>(dto.Priority, out var priority))
        {
            throw new AppException("Invalid priority.");
        }

        ticket.Title = dto.Title;
        ticket.Description = dto.Description;
        ticket.CategoryId = dto.CategoryId;

        if (ticket.Priority != priority)
        {
            ticket.Priority = priority;
            var (responseDueAt, resolutionDueAt) = await _slaService.CalculateDueDatesAsync(priority, ticket.CreatedAt);
            ticket.ResponseDueAt = responseDueAt;
            ticket.ResolutionDueAt = resolutionDueAt;
        }

        await SaveChangesWithConcurrencyCheckAsync(_context);

        await _auditService.LogAsync(actingUserId, "TicketUpdated", $"Ticket {ticket.TicketNumber} updated.", entityType: "Ticket", entityId: ticket.Id.ToString());

        await _notificationService.NotifyUserAsync(
            ticket.CreatedById,
            NotificationEvent.TicketUpdated,
            "Ticket Updated",
            $"Ticket {ticket.TicketNumber} has been updated.");

        return (await GetByIdAsync(ticket.Id))!;
    }

    public async Task<TicketDto> TakeOwnershipAsync(Guid id, Guid technicianUserId, string role, Guid? departmentId)
    {
        if (!await CanUserAccessTicketAsync(id, technicianUserId, role, departmentId))
        {
            throw new ForbiddenException("You do not have access to this ticket.");
        }

        var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.Id == id);
        if (ticket == null)
        {
            throw new NotFoundException("Ticket not found.");
        }

        // Hardening item 5: prevent double ownership. Reassignment must go through a
        // manager reassignment flow (not implemented in this codebase), not this endpoint.
        if (ticket.AssignedToId.HasValue)
        {
            throw new BusinessException("Ticket already has an assigned owner. Use manager reassignment instead.");
        }

        // Hardening item 1: workflow validation (New -> InProgress, i.e. New -> "Assigned").
        TicketWorkflow.EnsureValidTransition(ticket.Status, TicketStatus.InProgress);

        // Hardening item 4: assignment validation. The assignee here is always the calling
        // user (self-service take-ownership), but we still verify the user record itself is
        // active, not deleted, and holds an assignable role (Technician/IT Manager), in case
        // a stale JWT outlives a role change/deactivation within its lifetime.
        var technician = await _context.Users
            .Include(u => u.Role)
            .FirstOrDefaultAsync(u => u.Id == technicianUserId);

        if (technician == null)
        {
            throw new NotFoundException("Assigning user not found.");
        }

        if (technician.UserStatus != UserStatus.Active)
        {
            throw new BusinessException("Inactive or suspended users cannot take ownership of tickets.");
        }

        if (!AssignableRoles.Contains(technician.Role.Name))
        {
            throw new BusinessException("Only Technician or IT Manager users can take ownership of tickets.");
        }

        if (role != RoleNames.Admin && technician.DepartmentId != ticket.DepartmentId)
        {
            throw new BusinessException("You can only take ownership of tickets in your department.");
        }

        var now = DateTime.UtcNow;
        ticket.AssignedToId = technicianUserId;
        ticket.AssignedAt = now;
        ticket.Status = TicketStatus.InProgress;

        await SaveChangesWithConcurrencyCheckAsync(_context);

        await _auditService.LogAsync(technicianUserId, "TicketAssigned", $"Ticket {ticket.TicketNumber} ownership taken.", entityType: "Ticket", entityId: ticket.Id.ToString());

        await _notificationService.NotifyUserAsync(
            ticket.CreatedById,
            NotificationEvent.TicketAssigned,
            "Ticket Assigned",
            $"Your ticket {ticket.TicketNumber} has been picked up by a technician.");

        return (await GetByIdAsync(ticket.Id))!;
    }

    public async Task<TicketDto> ResolveAsync(Guid id, Guid actingUserId, string role, Guid? departmentId)
    {
        if (!await CanUserAccessTicketAsync(id, actingUserId, role, departmentId))
        {
            throw new ForbiddenException("You do not have access to this ticket.");
        }

        var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.Id == id);
        if (ticket == null)
        {
            throw new NotFoundException("Ticket not found.");
        }

        if (!CanPerformAgentAction(ticket, actingUserId, role, departmentId))
        {
            throw new BusinessException("Only the assigned agent or an authorized manager can resolve this ticket.");
        }

        // Hardening item 1: workflow validation.
        TicketWorkflow.EnsureValidTransition(ticket.Status, TicketStatus.Resolved);

        if (ticket.Status is TicketStatus.PendingUser or TicketStatus.PendingVendor)
        {
            await _slaService.ResumeResolutionSlaAsync(ticket);
        }

        ticket.Status = TicketStatus.Resolved;
        ticket.ResolvedAt = DateTime.UtcNow;

        await _slaService.EvaluateBreachesAsync(ticket);

        await SaveChangesWithConcurrencyCheckAsync(_context);

        await _auditService.LogAsync(actingUserId, "TicketResolved", $"Ticket {ticket.TicketNumber} resolved.", entityType: "Ticket", entityId: ticket.Id.ToString());

        await _notificationService.NotifyUserAsync(
            ticket.CreatedById,
            NotificationEvent.TicketResolved,
            "Ticket Resolved",
            $"Your ticket {ticket.TicketNumber} has been resolved. It will auto-close in 5 hours unless you reply or reopen it.");

        return (await GetByIdAsync(ticket.Id))!;
    }

    public async Task<TicketDto> CloseAsync(Guid id, Guid actingUserId, string role, Guid? departmentId)
    {
        if (!await CanUserAccessTicketAsync(id, actingUserId, role, departmentId))
        {
            throw new ForbiddenException("You do not have access to this ticket.");
        }

        var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.Id == id);
        if (ticket == null)
        {
            throw new NotFoundException("Ticket not found.");
        }

        if (!CanPerformAgentAction(ticket, actingUserId, role, departmentId))
        {
            throw new BusinessException("Only the assigned agent or an authorized manager can close this ticket.");
        }

        // Hardening item 6: close is only allowed from Resolved. This also follows from the
        // workflow matrix (item 1), but is checked explicitly with a clearer message.
        if (ticket.Status != TicketStatus.Resolved)
        {
            throw new BusinessException("Only resolved tickets can be closed.");
        }

        TicketWorkflow.EnsureValidTransition(ticket.Status, TicketStatus.Closed);

        ticket.Status = TicketStatus.Closed;
        ticket.ClosedAt = DateTime.UtcNow;

        await SaveChangesWithConcurrencyCheckAsync(_context);

        await _auditService.LogAsync(actingUserId, "TicketClosed", $"Ticket {ticket.TicketNumber} closed.", entityType: "Ticket", entityId: ticket.Id.ToString());

        await _notificationService.NotifyUserAsync(
            ticket.CreatedById,
            NotificationEvent.TicketClosed,
            "Ticket Closed",
            $"Your ticket {ticket.TicketNumber} has been closed.");

        return (await GetByIdAsync(ticket.Id))!;
    }

    public async Task<TicketDto> ChangeStatusAsync(Guid id, string status, Guid actingUserId, string role, Guid? departmentId)
    {
        if (!await CanUserAccessTicketAsync(id, actingUserId, role, departmentId))
        {
            throw new ForbiddenException("You do not have access to this ticket.");
        }

        var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.Id == id);
        if (ticket == null)
        {
            throw new NotFoundException("Ticket not found.");
        }

        if (!Enum.TryParse<TicketStatus>(status, out var newStatus))
        {
            throw new AppException("Invalid status.");
        }

        // Hardening item 1: centralized workflow validation for all status changes routed
        // through this endpoint (PendingUser/PendingVendor/back-to-InProgress/Cancelled).
        TicketWorkflow.EnsureValidTransition(ticket.Status, newStatus);

        // Hardening item 2: status changes driven by agent work (moving out of/into the
        // paused states, or back to InProgress) are restricted to the assigned agent or
        // authorized manager/admin. Reopening a Resolved ticket back to InProgress remains
        // available to the ticket creator as well, since that is the existing reopen path
        // used by the conversation auto-reopen behavior.
        var isCreator = ticket.CreatedById == actingUserId;
        var isCreatorReopen = ticket.Status == TicketStatus.Resolved && newStatus == TicketStatus.InProgress && isCreator;

        if (!isCreatorReopen && !CanPerformAgentAction(ticket, actingUserId, role, departmentId))
        {
            throw new BusinessException("Only the assigned agent or an authorized manager can change this ticket's status.");
        }

        var wasPaused = ticket.Status is TicketStatus.PendingUser or TicketStatus.PendingVendor;
        var willBePaused = newStatus is TicketStatus.PendingUser or TicketStatus.PendingVendor;

        if (!wasPaused && willBePaused)
        {
            await _slaService.PauseResolutionSlaAsync(ticket);
        }
        else if (wasPaused && !willBePaused)
        {
            await _slaService.ResumeResolutionSlaAsync(ticket);
        }

        ticket.Status = newStatus;

        if (newStatus == TicketStatus.InProgress)
        {
            ticket.ResolvedAt = null;
        }

        await SaveChangesWithConcurrencyCheckAsync(_context);

        await _auditService.LogAsync(actingUserId, "TicketStatusChanged", $"Ticket {ticket.TicketNumber} status changed to {newStatus}.", entityType: "Ticket", entityId: ticket.Id.ToString());

        await _notificationService.NotifyUserAsync(
            ticket.CreatedById,
            NotificationEvent.TicketUpdated,
            "Ticket Status Changed",
            $"Ticket {ticket.TicketNumber} status changed to {newStatus}.");

        return (await GetByIdAsync(ticket.Id))!;
    }

    public async Task<bool> CanUserAccessTicketAsync(Guid ticketId, Guid userId, string role, Guid? departmentId)
    {
        if (role == RoleNames.Admin) return true;

        var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.Id == ticketId);
        if (ticket == null) return false;

        if (AssignableRoles.Contains(role))
        {
            return departmentId.HasValue && ticket.DepartmentId == departmentId.Value;
        }

        return ticket.CreatedById == userId;
    }

    public async Task<bool> IsCreatorOrAssignedTechnicianAsync(Guid ticketId, Guid userId)
    {
        var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.Id == ticketId);
        if (ticket == null) return false;

        return ticket.CreatedById == userId || ticket.AssignedToId == userId;
    }
}
