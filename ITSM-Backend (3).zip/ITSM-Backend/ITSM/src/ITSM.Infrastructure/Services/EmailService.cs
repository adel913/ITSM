using ITSM.Application.Interfaces;
using Microsoft.Extensions.Configuration;
using Serilog;
using System.Net;
using System.Net.Mail;

namespace ITSM.Infrastructure.Services;

// SMTP-based email service. Configure Smtp:* settings in appsettings.json.
// Falls back to logging only if SMTP host is not configured, so the system
// remains runnable without a mail server during development.
public class EmailService : IEmailService
{
    private readonly IConfiguration _configuration;

    public EmailService(IConfiguration configuration)
    {
        _configuration = configuration;
    }

    public async Task SendEmailAsync(string toEmail, string subject, string body)
    {
        await SendEmailToManyAsync(new[] { toEmail }, subject, body);
    }

    public async Task SendEmailToManyAsync(IEnumerable<string> toEmails, string subject, string body)
    {
        var smtpSection = _configuration.GetSection("Smtp");
        var host = smtpSection["Host"];

        if (string.IsNullOrWhiteSpace(host))
        {
            Log.Information("SMTP not configured. Skipping real send. Subject: {Subject} | Recipients: {Recipients}",
                subject, string.Join(",", toEmails));
            return;
        }

        var port = int.Parse(smtpSection["Port"] ?? "587");
        var username = smtpSection["Username"];
        var password = smtpSection["Password"];
        var fromAddress = smtpSection["FromAddress"] ?? username ?? "no-reply@itsm.local";
        var enableSsl = bool.Parse(smtpSection["EnableSsl"] ?? "true");

        using var client = new SmtpClient(host, port)
        {
            Credentials = new NetworkCredential(username, password),
            EnableSsl = enableSsl
        };

        using var message = new MailMessage
        {
            From = new MailAddress(fromAddress),
            Subject = subject,
            Body = body,
            IsBodyHtml = false
        };

        foreach (var email in toEmails)
        {
            message.To.Add(email);
        }

        try
        {
            await client.SendMailAsync(message);
        }
        catch (Exception ex)
        {
            Log.Error(ex, "Failed to send email. Subject: {Subject}", subject);
        }
    }
}
