using AutoMapper;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Sla;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Domain.Enums;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Services;

public class SlaService : ISlaService
{
    private readonly ITSMDbContext _context;
    private readonly IMapper _mapper;
    private readonly INotificationService _notificationService;
    private readonly IAuditService _auditService;

    public SlaService(
        ITSMDbContext context,
        IMapper mapper,
        INotificationService notificationService,
        IAuditService auditService)
    {
        _context = context;
        _mapper = mapper;
        _notificationService = notificationService;
        _auditService = auditService;
    }

    public async Task<List<SlaPolicyDto>> GetAllAsync()
    {
        var policies = await _context.SlaPolicies.ToListAsync();
        return _mapper.Map<List<SlaPolicyDto>>(policies);
    }

    public async Task<SlaPolicyDto> UpdateAsync(TicketPriority priority, UpdateSlaPolicyDto dto)
    {
        var policy = await _context.SlaPolicies.FirstOrDefaultAsync(p => p.Priority == priority);
        if (policy == null)
        {
            throw new NotFoundException($"SLA policy for priority {priority} not found.");
        }

        policy.ResponseMinutes = dto.ResponseMinutes;
        policy.ResolutionMinutes = dto.ResolutionMinutes;

        await _context.SaveChangesAsync();

        return _mapper.Map<SlaPolicyDto>(policy);
    }

    public async Task<(DateTime responseDueAt, DateTime resolutionDueAt)> CalculateDueDatesAsync(TicketPriority priority, DateTime createdAtUtc)
    {
        var policy = await _context.SlaPolicies.FirstOrDefaultAsync(p => p.Priority == priority);
        if (policy == null)
        {
            throw new NotFoundException($"SLA policy for priority {priority} not found.");
        }

        // Response SLA starts at CreatedAt and never pauses.
        var responseDueAt = createdAtUtc.AddMinutes(policy.ResponseMinutes);

        // Resolution SLA also starts at CreatedAt; pauses are applied separately via
        // TotalPausedMinutes when evaluating breach status (see EvaluateBreachesAsync).
        var resolutionDueAt = createdAtUtc.AddMinutes(policy.ResolutionMinutes);

        return (responseDueAt, resolutionDueAt);
    }

    public async Task EvaluateBreachesAsync(Ticket ticket)
    {
        // Response SLA: validated against FirstResponseAt, never pauses.
        if (!ticket.IsResponseSlaBreached && ticket.ResponseDueAt.HasValue)
        {
            var responseTimestamp = ticket.FirstResponseAt ?? DateTime.UtcNow;
            if (responseTimestamp > ticket.ResponseDueAt.Value)
            {
                ticket.IsResponseSlaBreached = true;
                await NotifyBreach(ticket, "Response");
            }
        }

        // Resolution SLA: validated against ResolvedAt, adjusted for paused minutes
        // accumulated while ticket was PendingUser / PendingVendor.
        if (!ticket.IsResolutionSlaBreached && ticket.ResolutionDueAt.HasValue)
        {
            var effectiveDueAt = ticket.ResolutionDueAt.Value.AddMinutes(ticket.TotalPausedMinutes);
            var resolutionTimestamp = ticket.ResolvedAt ?? DateTime.UtcNow;

            if (resolutionTimestamp > effectiveDueAt)
            {
                ticket.IsResolutionSlaBreached = true;
                await NotifyBreach(ticket, "Resolution");
            }
        }
    }

    private async Task NotifyBreach(Ticket ticket, string slaType)
    {
        var recipients = new List<Guid> { ticket.CreatedById };
        if (ticket.AssignedToId.HasValue)
        {
            recipients.Add(ticket.AssignedToId.Value);
        }

        // Escalate to IT Managers in the ticket's department and the department manager.
        var departmentManagers = await _context.Users
            .Include(u => u.Role)
            .Where(u => u.DepartmentId == ticket.DepartmentId
                && u.Role.Name == RoleNames.ITManager
                && u.UserStatus == UserStatus.Active)
            .Select(u => u.Id)
            .ToListAsync();
        recipients.AddRange(departmentManagers);

        var department = await _context.Departments.FirstOrDefaultAsync(d => d.Id == ticket.DepartmentId);
        if (department?.ManagerId.HasValue == true)
        {
            recipients.Add(department.ManagerId.Value);
        }

        await _auditService.LogAsync(
            null,
            "SlaBreached",
            $"Ticket {ticket.TicketNumber} breached its {slaType} SLA.",
            entityType: "Ticket",
            entityId: ticket.Id.ToString());

        await _notificationService.NotifyUsersAsync(
            recipients.Distinct(),
            NotificationEvent.SlaBreached,
            $"{slaType} SLA Breached",
            $"Ticket {ticket.TicketNumber} has breached its {slaType} SLA.");
    }

    public async Task PauseResolutionSlaAsync(Ticket ticket)
    {
        // PendingUser / PendingVendor pauses Resolution SLA. Response SLA never pauses.
        if (ticket.PauseStartedAtUtc == null)
        {
            ticket.PauseStartedAtUtc = DateTime.UtcNow;
        }
        await Task.CompletedTask;
    }

    public async Task ResumeResolutionSlaAsync(Ticket ticket)
    {
        if (ticket.PauseStartedAtUtc.HasValue)
        {
            var pausedMinutes = (int)Math.Ceiling((DateTime.UtcNow - ticket.PauseStartedAtUtc.Value).TotalMinutes);
            ticket.TotalPausedMinutes += Math.Max(0, pausedMinutes);
            ticket.PauseStartedAtUtc = null;
        }
        await Task.CompletedTask;
    }
}
