using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Infrastructure.Persistence;
using Serilog;

namespace ITSM.Infrastructure.Services;

public class AuditService : IAuditService
{
    private readonly ITSMDbContext _context;

    public AuditService(ITSMDbContext context)
    {
        _context = context;
    }

    public async Task LogAsync(Guid? userId, string action, string? details = null, string? ipAddress = null, string? entityType = null, string? entityId = null)
    {
        var log = new AuditLog
        {
            UserId = userId,
            Action = action,
            Details = details,
            IpAddress = ipAddress,
            EntityType = entityType,
            EntityId = entityId
        };
        _context.AuditLogs.Add(log);
        await _context.SaveChangesAsync();
        Log.Information("AUDIT | User: {UserId} | Action: {Action} | EntityType: {EntityType} | EntityId: {EntityId} | Details: {Details} | IP: {Ip}",
            userId, action, entityType, entityId, details, ipAddress);
    }
}
