using AutoMapper;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Conversation;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Domain.Enums;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Services;

public class TicketConversationService : ITicketConversationService
{
    private readonly ITSMDbContext _context;
    private readonly IMapper _mapper;
    private readonly ITicketService _ticketService;
    private readonly ISlaService _slaService;

    public TicketConversationService(
        ITSMDbContext context,
        IMapper mapper,
        ITicketService ticketService,
        ISlaService slaService)
    {
        _context = context;
        _mapper = mapper;
        _ticketService = ticketService;
        _slaService = slaService;
    }

    private async Task EnsureAccessAsync(Guid ticketId, Guid userId)
    {
        // Visible only to Ticket Creator + Assigned Technician.
        if (!await _ticketService.IsCreatorOrAssignedTechnicianAsync(ticketId, userId))
        {
            throw new ForbiddenException("You do not have access to this ticket's conversation.");
        }
    }

    public async Task<List<ConversationMessageDto>> GetMessagesAsync(Guid ticketId, Guid currentUserId)
    {
        await EnsureAccessAsync(ticketId, currentUserId);

        var messages = await _context.TicketConversationMessages
            .Include(m => m.Sender)
            .Where(m => m.TicketId == ticketId)
            .OrderBy(m => m.CreatedAt)
            .ToListAsync();

        return _mapper.Map<List<ConversationMessageDto>>(messages);
    }

    public async Task<ConversationMessageDto> SendMessageAsync(SendConversationMessageDto dto, Guid senderId)
    {
        await EnsureAccessAsync(dto.TicketId, senderId);

        var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.Id == dto.TicketId);
        if (ticket == null)
        {
            throw new NotFoundException("Ticket not found.");
        }

        // Hardening item 7: no new messages once a ticket is Closed or Cancelled.
        if (ticket.Status is TicketStatus.Closed or TicketStatus.Cancelled)
        {
            throw new BusinessException("Cannot send messages on a closed or cancelled ticket.");
        }

        var message = new TicketConversationMessage
        {
            TicketId = dto.TicketId,
            SenderId = senderId,
            Message = dto.Message
        };

        _context.TicketConversationMessages.Add(message);

        // First Response SLA: record only when the assigned agent sends the first
        // customer-visible reply. Must not be triggered by assignment, status changes,
        // or internal notes/chat.
        if (!ticket.FirstResponseAt.HasValue
            && ticket.AssignedToId == senderId
            && ticket.CreatedById != senderId)
        {
            ticket.FirstResponseAt = DateTime.UtcNow;
            await _slaService.EvaluateBreachesAsync(ticket);
        }

        // A reply from the ticket creator while Resolved should cancel the auto-close
        // countdown by moving the ticket back to InProgress (per spec: "If ticket creator
        // does not send any reply ... within 5 hours" implies a reply prevents auto-close).
        if (ticket.Status == TicketStatus.Resolved && senderId == ticket.CreatedById)
        {
            ticket.Status = TicketStatus.InProgress;
            ticket.ResolvedAt = null;
        }

        await _context.SaveChangesAsync();

        var saved = await _context.TicketConversationMessages
            .Include(m => m.Sender)
            .FirstAsync(m => m.Id == message.Id);

        return _mapper.Map<ConversationMessageDto>(saved);
    }
}
