using AutoMapper;
using ITSM.Application.Common;
using ITSM.Application.DTOs.Attachment;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Infrastructure.Persistence;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace ITSM.Infrastructure.Services;

public class TicketAttachmentService : ITicketAttachmentService
{
    private static readonly Dictionary<string, string[]> AllowedTypeExtensions = new()
    {
        ["application/pdf"] = new[] { ".pdf" },
        ["application/vnd.openxmlformats-officedocument.wordprocessingml.document"] = new[] { ".docx" },
        ["application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"] = new[] { ".xlsx" },
        ["image/jpeg"] = new[] { ".jpg", ".jpeg" },
        ["image/png"] = new[] { ".png" },
        ["application/zip"] = new[] { ".zip" },
        ["application/x-zip-compressed"] = new[] { ".zip" }
    };

    private static readonly string[] AllowedExtensions = { ".pdf", ".docx", ".xlsx", ".jpg", ".jpeg", ".png", ".zip" };

    private const long MaxFileSizeBytes = 25 * 1024 * 1024; // 25 MB

    private readonly ITSMDbContext _context;
    private readonly IMapper _mapper;
    private readonly string _storageRoot;

    public TicketAttachmentService(ITSMDbContext context, IMapper mapper, IConfiguration configuration)
    {
        _context = context;
        _mapper = mapper;
        _storageRoot = configuration["Attachments:StorageRoot"] ?? Path.Combine(AppContext.BaseDirectory, "attachments");
        Directory.CreateDirectory(_storageRoot);
    }

    public async Task<List<TicketAttachmentDto>> GetForTicketAsync(Guid ticketId)
    {
        var attachments = await _context.TicketAttachments
            .Include(a => a.UploadedBy)
            .Where(a => a.TicketId == ticketId)
            .OrderByDescending(a => a.UploadedAt)
            .ToListAsync();

        return _mapper.Map<List<TicketAttachmentDto>>(attachments);
    }

    public async Task<TicketAttachmentDto> UploadAsync(Guid ticketId, IFormFile file, Guid uploadedById)
    {
        var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.Id == ticketId);
        if (ticket == null)
        {
            throw new NotFoundException("Ticket not found.");
        }

        if (file == null || file.Length == 0)
        {
            throw new AppException("File is required.");
        }

        if (file.Length > MaxFileSizeBytes)
        {
            throw new AppException("File exceeds the maximum allowed size of 25 MB.");
        }

        var extension = Path.GetExtension(file.FileName).ToLowerInvariant();
        if (!AllowedExtensions.Contains(extension))
        {
            throw new AppException("File type not allowed. Allowed types: PDF, DOCX, XLSX, JPG, PNG, ZIP.");
        }

        var storedFileName = $"{Guid.NewGuid()}{extension}";
        var storedPath = Path.Combine(_storageRoot, storedFileName);

        using (var stream = new FileStream(storedPath, FileMode.Create))
        {
            await file.CopyToAsync(stream);
        }

        var attachment = new TicketAttachment
        {
            TicketId = ticketId,
            FileName = file.FileName,
            StoredFileName = storedFileName,
            ContentType = file.ContentType,
            FileSize = file.Length,
            UploadedById = uploadedById,
            UploadedAt = DateTime.UtcNow
        };

        _context.TicketAttachments.Add(attachment);
        await _context.SaveChangesAsync();

        var saved = await _context.TicketAttachments
            .Include(a => a.UploadedBy)
            .FirstAsync(a => a.Id == attachment.Id);

        return _mapper.Map<TicketAttachmentDto>(saved);
    }

    public async Task<(byte[] content, string contentType, string fileName)> DownloadAsync(Guid ticketId, Guid attachmentId)
    {
        var attachment = await _context.TicketAttachments.FirstOrDefaultAsync(a => a.Id == attachmentId);
        if (attachment == null)
        {
            throw new NotFoundException("Attachment not found.");
        }

        if (attachment.TicketId != ticketId)
        {
            throw new ForbiddenException("Attachment does not belong to this ticket.");
        }

        var storedPath = Path.Combine(_storageRoot, attachment.StoredFileName);
        if (!File.Exists(storedPath))
        {
            throw new NotFoundException("Attachment file is missing from storage.");
        }

        var bytes = await File.ReadAllBytesAsync(storedPath);
        return (bytes, attachment.ContentType, attachment.FileName);
    }
}
