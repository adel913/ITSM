using AutoMapper;
using ITSM.Application.Common;
using ITSM.Application.DTOs.InternalChat;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Domain.Enums;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Services;

public class TicketInternalChatService : ITicketInternalChatService
{
    private readonly ITSMDbContext _context;
    private readonly IMapper _mapper;

    public TicketInternalChatService(ITSMDbContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    // NOTE: Access restriction to "IT Department users" is enforced one layer up
    // (controller/hub), which checks IItUserDirectory.IsItRole against the caller's role
    // claim, since this service has no access to the caller's identity by design.

    public async Task<List<InternalMessageDto>> GetMessagesAsync(Guid ticketId)
    {
        var ticketExists = await _context.Tickets.AnyAsync(t => t.Id == ticketId);
        if (!ticketExists)
        {
            throw new NotFoundException("Ticket not found.");
        }

        var messages = await _context.TicketInternalMessages
            .Include(m => m.Sender)
            .Where(m => m.TicketId == ticketId)
            .OrderBy(m => m.CreatedAt)
            .ToListAsync();

        return _mapper.Map<List<InternalMessageDto>>(messages);
    }

    public async Task<InternalMessageDto> SendMessageAsync(SendInternalMessageDto dto, Guid senderId)
    {
        var ticket = await _context.Tickets.FirstOrDefaultAsync(t => t.Id == dto.TicketId);
        if (ticket == null)
        {
            throw new NotFoundException("Ticket not found.");
        }

        // Hardening item 7: no new messages once a ticket is Closed or Cancelled.
        if (ticket.Status is TicketStatus.Closed or TicketStatus.Cancelled)
        {
            throw new BusinessException("Cannot send messages on a closed or cancelled ticket.");
        }

        var message = new TicketInternalMessage
        {
            TicketId = dto.TicketId,
            SenderId = senderId,
            Message = dto.Message
        };

        _context.TicketInternalMessages.Add(message);
        await _context.SaveChangesAsync();

        var saved = await _context.TicketInternalMessages
            .Include(m => m.Sender)
            .FirstAsync(m => m.Id == message.Id);

        return _mapper.Map<InternalMessageDto>(saved);
    }
}
