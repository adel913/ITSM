using ITSM.Application.Common;
using ITSM.Application.Interfaces;
using ITSM.Infrastructure.Persistence;
using ITSM.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Services;

public class ItUserDirectory : IItUserDirectory
{
    private static readonly string[] ItRoles = { RoleNames.Admin, RoleNames.ITManager, RoleNames.Technician };

    private readonly ITSMDbContext _context;

    public ItUserDirectory(ITSMDbContext context)
    {
        _context = context;
    }

    public bool IsItRole(string? roleName) => roleName != null && ItRoles.Contains(roleName);

    public async Task<List<Guid>> GetItUserIdsAsync()
    {
        return await _context.Users
            .Where(u => ItRoles.Contains(u.Role.Name) && u.UserStatus == UserStatus.Active)
            .Select(u => u.Id)
            .ToListAsync();
    }

    public async Task<List<string>> GetItUserEmailsAsync()
    {
        return await _context.Users
            .Where(u => ItRoles.Contains(u.Role.Name) && u.UserStatus == UserStatus.Active)
            .Select(u => u.Email)
            .ToListAsync();
    }
}
