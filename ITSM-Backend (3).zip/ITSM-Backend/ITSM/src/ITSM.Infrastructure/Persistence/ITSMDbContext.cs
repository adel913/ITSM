using ITSM.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Persistence;

public class ITSMDbContext : DbContext
{
    public ITSMDbContext(DbContextOptions<ITSMDbContext> options) : base(options) { }

    public DbSet<User> Users => Set<User>();
    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Role> Roles => Set<Role>();
    public DbSet<Permission> Permissions => Set<Permission>();
    public DbSet<RolePermission> RolePermissions => Set<RolePermission>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();
    public DbSet<Ticket> Tickets => Set<Ticket>();
    public DbSet<TicketCategory> TicketCategories => Set<TicketCategory>();
    public DbSet<TicketConversationMessage> TicketConversationMessages => Set<TicketConversationMessage>();
    public DbSet<TicketInternalMessage> TicketInternalMessages => Set<TicketInternalMessage>();
    public DbSet<SlaPolicy> SlaPolicies => Set<SlaPolicy>();
    public DbSet<Notification> Notifications => Set<Notification>();
    public DbSet<TicketAttachment> TicketAttachments => Set<TicketAttachment>();
    public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(b =>
        {
            b.HasIndex(x => x.Email).IsUnique();
            b.HasIndex(x => x.EmployeeCode).IsUnique();
            b.HasOne(x => x.Department).WithMany(d => d.Users).HasForeignKey(x => x.DepartmentId).OnDelete(DeleteBehavior.Restrict);
            b.HasOne(x => x.Role).WithMany(r => r.Users).HasForeignKey(x => x.RoleId).OnDelete(DeleteBehavior.Restrict);
            b.HasQueryFilter(x => !x.IsDeleted);
        });

        modelBuilder.Entity<Department>(b =>
        {
            b.HasOne(x => x.Manager).WithMany().HasForeignKey(x => x.ManagerId).OnDelete(DeleteBehavior.Restrict);
            // Hardening item 15: soft delete instead of physical removal.
            b.HasQueryFilter(x => !x.IsDeleted);
        });

        modelBuilder.Entity<Role>(b =>
        {
            b.HasIndex(x => x.Name).IsUnique();
        });

        modelBuilder.Entity<Permission>(b =>
        {
            b.HasIndex(x => new { x.Module, x.Action }).IsUnique();
        });

        modelBuilder.Entity<RolePermission>(b =>
        {
            b.HasOne(x => x.Role).WithMany(r => r.RolePermissions).HasForeignKey(x => x.RoleId).OnDelete(DeleteBehavior.Cascade);
            b.HasOne(x => x.Permission).WithMany(p => p.RolePermissions).HasForeignKey(x => x.PermissionId).OnDelete(DeleteBehavior.Cascade);
            b.HasIndex(x => new { x.RoleId, x.PermissionId }).IsUnique();
        });

        modelBuilder.Entity<RefreshToken>(b =>
        {
            b.HasOne(x => x.User).WithMany(u => u.RefreshTokens).HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Ticket>(b =>
        {
            b.HasIndex(x => x.TicketNumber).IsUnique();
            b.HasOne(x => x.CreatedBy).WithMany().HasForeignKey(x => x.CreatedById).OnDelete(DeleteBehavior.Restrict);
            b.HasOne(x => x.AssignedTo).WithMany().HasForeignKey(x => x.AssignedToId).OnDelete(DeleteBehavior.Restrict);
            b.HasOne(x => x.Category).WithMany(c => c.Tickets).HasForeignKey(x => x.CategoryId).OnDelete(DeleteBehavior.Restrict);
            b.HasOne(x => x.Department).WithMany().HasForeignKey(x => x.DepartmentId).OnDelete(DeleteBehavior.Restrict);

            // Hardening item 11: optimistic concurrency token (also configured via [Timestamp]
            // on the entity; explicit here for clarity/portability).
            b.Property(x => x.RowVersion).IsRowVersion();

            // Hardening item 10: query performance indexes.
            b.HasIndex(x => x.Status);
            b.HasIndex(x => x.AssignedToId);
            b.HasIndex(x => x.CreatedById);
            b.HasIndex(x => x.DepartmentId);
            b.HasIndex(x => x.Priority);
            b.HasIndex(x => x.CreatedAt);
        });

        modelBuilder.Entity<TicketCategory>(b =>
        {
            b.HasIndex(x => x.Name).IsUnique();
        });

        modelBuilder.Entity<TicketConversationMessage>(b =>
        {
            b.HasOne(x => x.Ticket).WithMany(t => t.ConversationMessages).HasForeignKey(x => x.TicketId).OnDelete(DeleteBehavior.Cascade);
            b.HasOne(x => x.Sender).WithMany().HasForeignKey(x => x.SenderId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<TicketInternalMessage>(b =>
        {
            b.HasOne(x => x.Ticket).WithMany(t => t.InternalMessages).HasForeignKey(x => x.TicketId).OnDelete(DeleteBehavior.Cascade);
            b.HasOne(x => x.Sender).WithMany().HasForeignKey(x => x.SenderId).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<SlaPolicy>(b =>
        {
            b.HasIndex(x => x.Priority).IsUnique();
        });

        modelBuilder.Entity<Notification>(b =>
        {
            b.HasOne(x => x.User).WithMany().HasForeignKey(x => x.UserId).OnDelete(DeleteBehavior.Cascade);
            b.HasIndex(x => new { x.UserId, x.IsRead });
        });

        modelBuilder.Entity<TicketAttachment>(b =>
        {
            b.HasOne(x => x.Ticket).WithMany(t => t.Attachments).HasForeignKey(x => x.TicketId).OnDelete(DeleteBehavior.Cascade);
            b.HasOne(x => x.UploadedBy).WithMany().HasForeignKey(x => x.UploadedById).OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<AuditLog>(b =>
        {
            b.HasIndex(x => x.UserId);
        });
    }
}
