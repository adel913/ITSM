using ITSM.Application.Common;
using ITSM.Application.Interfaces;
using ITSM.Domain.Entities;
using ITSM.Domain.Enums;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace ITSM.Infrastructure.Persistence.Seed;

public static class DbSeeder
{
    public static async Task SeedAsync(ITSMDbContext context, IPasswordHasher passwordHasher)
    {
        await context.Database.MigrateAsync();

        // ---------------- Roles ----------------
        var roleNames = new[] { RoleNames.Admin, RoleNames.ITManager, RoleNames.Technician, RoleNames.Employee };
        foreach (var roleName in roleNames)
        {
            if (!await context.Roles.AnyAsync(r => r.Name == roleName))
            {
                context.Roles.Add(new Role { Name = roleName });
            }
        }
        await context.SaveChangesAsync();

        // ---------------- Permissions ----------------
        var permissionDefinitions = new (string Module, string Action)[]
        {
            ("user", "create"),
            ("user", "update"),
            ("user", "delete"),
            ("department", "create"),
            ("department", "update"),

            ("ticket", "view"),
            ("ticket", "create"),
            ("ticket", "update"),
            ("ticket", "takeownership"),
            ("ticket", "resolve"),
            ("ticket", "close"),

            ("ticket.chat", "view"),
            ("ticket.chat", "send"),

            ("sla", "view"),
            ("sla", "manage"),

            ("notification", "view"),

            ("asset", "create"),
            ("asset", "update"),
            ("report", "view"),
            ("approval", "approve")
        };

        foreach (var (module, action) in permissionDefinitions)
        {
            if (!await context.Permissions.AnyAsync(p => p.Module == module && p.Action == action))
            {
                context.Permissions.Add(new Permission { Module = module, Action = action });
            }
        }
        await context.SaveChangesAsync();

        var allRoles = await context.Roles.ToListAsync();
        var allPermissions = await context.Permissions.ToListAsync();

        Permission Find(string module, string action) =>
            allPermissions.First(p => p.Module == module && p.Action == action);

        var adminRole = allRoles.First(r => r.Name == RoleNames.Admin);
        var itManagerRole = allRoles.First(r => r.Name == RoleNames.ITManager);
        var technicianRole = allRoles.First(r => r.Name == RoleNames.Technician);
        var employeeRole = allRoles.First(r => r.Name == RoleNames.Employee);

        async Task AssignAsync(Role role, IEnumerable<Permission> permissions)
        {
            foreach (var permission in permissions)
            {
                var exists = await context.RolePermissions
                    .AnyAsync(rp => rp.RoleId == role.Id && rp.PermissionId == permission.Id);
                if (!exists)
                {
                    context.RolePermissions.Add(new RolePermission { RoleId = role.Id, PermissionId = permission.Id });
                }
            }
        }

        // Admin: full access to everything defined in spec.
        await AssignAsync(adminRole, allPermissions);

        // IT Manager: full ticket lifecycle, chat, SLA management, notifications, asset/report/approval.
        await AssignAsync(itManagerRole, new[]
        {
            Find("user", "create"),
            Find("user", "update"),
            Find("department", "create"),
            Find("department", "update"),
            Find("ticket", "view"),
            Find("ticket", "create"),
            Find("ticket", "update"),
            Find("ticket", "takeownership"),
            Find("ticket", "resolve"),
            Find("ticket", "close"),
            Find("ticket.chat", "view"),
            Find("ticket.chat", "send"),
            Find("sla", "view"),
            Find("sla", "manage"),
            Find("notification", "view"),
            Find("asset", "create"),
            Find("asset", "update"),
            Find("report", "view"),
            Find("approval", "approve")
        });

        // Technician: ticket view/update/takeownership/resolve/close, chat view/send, sla view, notifications, asset.
        await AssignAsync(technicianRole, new[]
        {
            Find("ticket", "view"),
            Find("ticket", "update"),
            Find("ticket", "takeownership"),
            Find("ticket", "resolve"),
            Find("ticket", "close"),
            Find("ticket.chat", "view"),
            Find("ticket.chat", "send"),
            Find("sla", "view"),
            Find("notification", "view"),
            Find("asset", "create"),
            Find("asset", "update")
        });

        // Employee: create/view own tickets, chat view/send (user conversation only), notifications.
        await AssignAsync(employeeRole, new[]
        {
            Find("ticket", "view"),
            Find("ticket", "create"),
            Find("ticket", "update"),
            Find("ticket.chat", "view"),
            Find("ticket.chat", "send"),
            Find("notification", "view")
        });

        await context.SaveChangesAsync();

        // ---------------- Default Department ----------------
        if (!await context.Departments.AnyAsync())
        {
            context.Departments.Add(new Department
            {
                Name = "IT Department",
                Description = "Default IT department",
                IsActive = true
            });
            await context.SaveChangesAsync();
        }

        var defaultDepartment = await context.Departments.FirstAsync();

        // ---------------- Default Admin User ----------------
        if (!await context.Users.AnyAsync(u => u.Email == "admin@itsm.local"))
        {
            context.Users.Add(new User
            {
                EmployeeCode = "EMP-0001",
                FullName = "System Administrator",
                Email = "admin@itsm.local",
                Phone = null,
                PasswordHash = passwordHasher.Hash("Admin@12345"),
                DepartmentId = defaultDepartment.Id,
                RoleId = adminRole.Id,
                UserStatus = UserStatus.Active,
                IsDeleted = false
            });
            await context.SaveChangesAsync();
        }

        // ---------------- Ticket Categories ----------------
        var categoryNames = new[] { "Hardware", "Software", "Network", "Printer", "Email", "Security", "Server", "Other" };
        foreach (var name in categoryNames)
        {
            if (!await context.TicketCategories.AnyAsync(c => c.Name == name))
            {
                context.TicketCategories.Add(new TicketCategory { Name = name, IsActive = true });
            }
        }
        await context.SaveChangesAsync();

        // ---------------- SLA Policies ----------------
        var slaDefinitions = new (TicketPriority Priority, int ResponseMinutes, int ResolutionMinutes)[]
        {
            (TicketPriority.Critical, 15, 4 * 60),
            (TicketPriority.High, 30, 8 * 60),
            (TicketPriority.Medium, 2 * 60, 24 * 60),
            (TicketPriority.Low, 8 * 60, 72 * 60)
        };

        foreach (var (priority, responseMinutes, resolutionMinutes) in slaDefinitions)
        {
            if (!await context.SlaPolicies.AnyAsync(p => p.Priority == priority))
            {
                context.SlaPolicies.Add(new SlaPolicy
                {
                    Priority = priority,
                    ResponseMinutes = responseMinutes,
                    ResolutionMinutes = resolutionMinutes
                });
            }
        }
        await context.SaveChangesAsync();
    }
}
