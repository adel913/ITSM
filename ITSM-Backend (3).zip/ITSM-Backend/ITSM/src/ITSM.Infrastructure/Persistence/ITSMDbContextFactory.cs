using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;

namespace ITSM.Infrastructure.Persistence;

// Used by EF Core CLI tools (dotnet ef migrations add / dotnet ef database update)
// to construct the DbContext at design time without running Program.cs.
public class ITSMDbContextFactory : IDesignTimeDbContextFactory<ITSMDbContext>
{
    public ITSMDbContext CreateDbContext(string[] args)
    {
        var configuration = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json", optional: true)
            .AddEnvironmentVariables()
            .Build();

        var connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? "Server=localhost,1433;Database=ITSMDb;User Id=sa;Password=Your_password123;TrustServerCertificate=True;";

        var optionsBuilder = new DbContextOptionsBuilder<ITSMDbContext>();
        optionsBuilder.UseSqlServer(connectionString);

        return new ITSMDbContext(optionsBuilder.Options);
    }
}
