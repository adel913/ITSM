using ITSM.Application.Interfaces;
using ITSM.Domain.Enums;
using ITSM.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;

namespace ITSM.Infrastructure.BackgroundServices;

// Runs periodically to:
// 1. Auto-close tickets that have been Resolved for configured hours with no creator reply/reopen.
// 2. Evaluate Response/Resolution SLA breaches for open tickets.
public class TicketLifecycleBackgroundService : BackgroundService
{
    private static readonly TimeSpan PollInterval = TimeSpan.FromMinutes(1);
    private const int DefaultAutoCloseHours = 5;

    private readonly IServiceProvider _serviceProvider;

    public TicketLifecycleBackgroundService(IServiceProvider serviceProvider)
    {
        _serviceProvider = serviceProvider;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            try
            {
                await RunCycleAsync(stoppingToken);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "TicketLifecycleBackgroundService cycle failed.");
            }

            await Task.Delay(PollInterval, stoppingToken);
        }
    }

    private async Task RunCycleAsync(CancellationToken stoppingToken)
    {
        using var scope = _serviceProvider.CreateScope();
        var context = scope.ServiceProvider.GetRequiredService<ITSMDbContext>();
        var configuration = scope.ServiceProvider.GetRequiredService<IConfiguration>();
        var slaService = scope.ServiceProvider.GetRequiredService<ISlaService>();
        var notificationService = scope.ServiceProvider.GetRequiredService<INotificationService>();
        var auditService = scope.ServiceProvider.GetRequiredService<IAuditService>();

        var autoCloseHours = configuration.GetValue("Tickets:AutoCloseHours", DefaultAutoCloseHours);
        if (autoCloseHours <= 0)
        {
            autoCloseHours = DefaultAutoCloseHours;
        }

        var autoCloseWindow = TimeSpan.FromHours(autoCloseHours);
        var now = DateTime.UtcNow;

        // ---- Auto-close Resolved tickets after configured inactivity window ----
        var resolvedTickets = await context.Tickets
            .Where(t => t.Status == TicketStatus.Resolved && t.ResolvedAt.HasValue)
            .ToListAsync(stoppingToken);

        foreach (var ticket in resolvedTickets)
        {
            var elapsed = now - ticket.ResolvedAt!.Value;

            if (elapsed >= autoCloseWindow)
            {
                ticket.Status = TicketStatus.Closed;
                ticket.ClosedAt = now;

                await auditService.LogAsync(
                    null,
                    "TicketAutoClosed",
                    $"Ticket {ticket.TicketNumber} auto-closed after {autoCloseHours} hours of inactivity.",
                    entityType: "Ticket",
                    entityId: ticket.Id.ToString());

                await notificationService.NotifyUserAsync(
                    ticket.CreatedById,
                    NotificationEvent.TicketClosed,
                    "Ticket Auto-Closed",
                    $"Ticket {ticket.TicketNumber} was automatically closed after {autoCloseHours} hours with no reply.");
            }
            else if (elapsed >= autoCloseWindow - TimeSpan.FromMinutes(30) && elapsed < autoCloseWindow - TimeSpan.FromMinutes(29))
            {
                // Best-effort one-time warning ~30 minutes before auto-close.
                await notificationService.NotifyUserAsync(
                    ticket.CreatedById,
                    NotificationEvent.TicketUpdated,
                    "Ticket Closing Soon",
                    $"Ticket {ticket.TicketNumber} will auto-close soon unless you reply or reopen it.");
            }
        }

        // ---- Evaluate SLA breaches for active (non-terminal) tickets ----
        var activeTickets = await context.Tickets
            .Where(t => t.Status != TicketStatus.Closed && t.Status != TicketStatus.Cancelled)
            .Where(t => !t.IsResponseSlaBreached || !t.IsResolutionSlaBreached)
            .ToListAsync(stoppingToken);

        foreach (var ticket in activeTickets)
        {
            await slaService.EvaluateBreachesAsync(ticket);
        }

        await context.SaveChangesAsync(stoppingToken);
    }
}
