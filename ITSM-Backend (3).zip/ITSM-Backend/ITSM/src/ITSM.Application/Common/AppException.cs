namespace ITSM.Application.Common;

public class AppException : Exception
{
    public int StatusCode { get; }
    public AppException(string message, int statusCode = 400) : base(message)
    {
        StatusCode = statusCode;
    }
}

public class NotFoundException : AppException
{
    public NotFoundException(string message) : base(message, 404) { }
}

public class ForbiddenException : AppException
{
    public ForbiddenException(string message) : base(message, 403) { }
}

public class UnauthorizedAppException : AppException
{
    public UnauthorizedAppException(string message) : base(message, 401) { }
}

// Alias for generic 400 business-rule violations (workflow, ownership, assignment, etc).
// Functionally identical to AppException(message, 400); added so call sites and the
// exception middleware can express intent explicitly per the "BusinessException => 400"
// hardening requirement, without changing AppException's existing behavior.
public class BusinessException : AppException
{
    public BusinessException(string message) : base(message, 400) { }
}

// Raised when a concurrent update is detected via the Ticket RowVersion concurrency token.
public class ConcurrencyException : AppException
{
    public ConcurrencyException(string message) : base(message, 409) { }
}
