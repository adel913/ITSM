namespace ITSM.Application.Common;

public static class RoleNames
{
    public const string Admin = "Admin";
    public const string ITManager = "IT Manager";
    public const string Technician = "Technician";
    public const string Employee = "Employee";
}

public static class PermissionCodes
{
    public const string UserCreate = "user.create";
    public const string UserUpdate = "user.update";
    public const string UserDelete = "user.delete";

    public const string DepartmentCreate = "department.create";
    public const string DepartmentUpdate = "department.update";

    public const string TicketCreate = "ticket.create";
    public const string TicketView = "ticket.view";
    public const string TicketUpdate = "ticket.update";
    public const string TicketTakeOwnership = "ticket.takeownership";
    public const string TicketResolve = "ticket.resolve";
    public const string TicketClose = "ticket.close";

    public const string TicketChatView = "ticket.chat.view";
    public const string TicketChatSend = "ticket.chat.send";

    public const string SlaView = "sla.view";
    public const string SlaManage = "sla.manage";

    public const string NotificationView = "notification.view";

    public const string AssetCreate = "asset.create";
    public const string AssetUpdate = "asset.update";

    public const string ReportView = "report.view";
    public const string ApprovalApprove = "approval.approve";
}
