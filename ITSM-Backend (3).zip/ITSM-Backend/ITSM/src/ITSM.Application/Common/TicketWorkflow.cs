using ITSM.Domain.Enums;

namespace ITSM.Application.Common;

// Centralized ticket status transition validation (Hardening item #1).
//
// NOTE: the requested transition matrix references a "New -> Assigned -> InProgress" path,
// but the existing TicketStatus enum (unchanged, per "do not rename enums") has no Assigned
// status — TakeOwnershipAsync moves a ticket straight from New to InProgress while stamping
// AssignedToId/AssignedAt. "Assigned" is therefore treated as a transient business concept
// represented by AssignedToId being set, not a distinct status value. The matrix below is
// the requested one with that single substitution (Assigned collapsed into InProgress);
// every other transition is exactly as specified.
public static class TicketWorkflow
{
    private static readonly Dictionary<TicketStatus, TicketStatus[]> AllowedTransitions = new()
    {
        // New -> Assigned -> InProgress collapses to New -> InProgress (see note above),
        // performed exclusively by TakeOwnershipAsync.
        [TicketStatus.New] = new[] { TicketStatus.InProgress },

        [TicketStatus.InProgress] = new[] { TicketStatus.PendingUser, TicketStatus.PendingVendor, TicketStatus.Resolved },

        [TicketStatus.PendingUser] = new[] { TicketStatus.InProgress, TicketStatus.Resolved },

        [TicketStatus.PendingVendor] = new[] { TicketStatus.InProgress, TicketStatus.Resolved },

        [TicketStatus.Resolved] = new[] { TicketStatus.Closed, TicketStatus.InProgress },

        [TicketStatus.Closed] = Array.Empty<TicketStatus>(),

        [TicketStatus.Cancelled] = Array.Empty<TicketStatus>()
    };

    public static bool IsValidTransition(TicketStatus from, TicketStatus to)
    {
        if (from == to) return false;
        return AllowedTransitions.TryGetValue(from, out var allowed) && allowed.Contains(to);
    }

    public static void EnsureValidTransition(TicketStatus from, TicketStatus to)
    {
        if (!IsValidTransition(from, to))
        {
            throw new BusinessException($"Invalid ticket status transition from {from} to {to}.");
        }
    }
}
