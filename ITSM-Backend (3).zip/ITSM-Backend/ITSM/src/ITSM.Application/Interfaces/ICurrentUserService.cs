namespace ITSM.Application.Interfaces;

public interface ICurrentUserService
{
    Guid? UserId { get; }
    string? Email { get; }
    string? Role { get; }
    Guid? DepartmentId { get; }
    IEnumerable<string> Permissions { get; }
    bool HasPermission(string permissionCode);
    string? IpAddress { get; }
}
