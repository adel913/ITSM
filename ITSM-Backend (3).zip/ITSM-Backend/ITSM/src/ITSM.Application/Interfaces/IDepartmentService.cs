using ITSM.Application.DTOs.Department;

namespace ITSM.Application.Interfaces;

public interface IDepartmentService
{
    Task<List<DepartmentDto>> GetAllAsync();
    Task<DepartmentDto?> GetByIdAsync(Guid id);
    Task<DepartmentDto> CreateAsync(CreateDepartmentDto dto, Guid actingUserId);
    Task<DepartmentDto> UpdateAsync(Guid id, UpdateDepartmentDto dto, Guid actingUserId);
    Task DeleteAsync(Guid id, Guid actingUserId);
}
