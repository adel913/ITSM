using ITSM.Application.DTOs.Ticket;

namespace ITSM.Application.Interfaces;

public interface ITicketService
{
    // Hardening item 3 (department isolation): GetAllAsync/CanUserAccessTicketAsync now take
    // the caller's role + departmentId instead of a single isItUser bool, so visibility can be
    // scoped per-role (Admin: all; Technician/IT Manager "Agent/Manager": own department only;
    // Employee: own tickets only) instead of all-IT-roles-see-everything.
    Task<List<TicketDto>> GetAllAsync(Guid currentUserId, string role, Guid? departmentId);
    Task<TicketDto?> GetByIdAsync(Guid id);
    Task<TicketDto> CreateAsync(CreateTicketDto dto, Guid creatorUserId);
    Task<TicketDto> UpdateAsync(Guid id, UpdateTicketDto dto, Guid actingUserId);
    Task<TicketDto> TakeOwnershipAsync(Guid id, Guid technicianUserId, string role, Guid? departmentId);
    Task<TicketDto> ResolveAsync(Guid id, Guid actingUserId, string role, Guid? departmentId);
    Task<TicketDto> CloseAsync(Guid id, Guid actingUserId, string role, Guid? departmentId);
    Task<TicketDto> ChangeStatusAsync(Guid id, string status, Guid actingUserId, string role, Guid? departmentId);
    Task<bool> CanUserAccessTicketAsync(Guid ticketId, Guid userId, string role, Guid? departmentId);
    Task<bool> IsCreatorOrAssignedTechnicianAsync(Guid ticketId, Guid userId);
}
