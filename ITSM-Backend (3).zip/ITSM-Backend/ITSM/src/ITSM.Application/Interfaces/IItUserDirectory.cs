namespace ITSM.Application.Interfaces;

// Resolves which users count as "IT Department users" for ticket visibility, internal chat
// access, and IT-wide notifications. Defined by role membership (Admin, IT Manager,
// Technician) since the existing Department entity has no "IsITDepartment" flag.
public interface IItUserDirectory
{
    Task<List<Guid>> GetItUserIdsAsync();
    Task<List<string>> GetItUserEmailsAsync();
    bool IsItRole(string? roleName);
}
