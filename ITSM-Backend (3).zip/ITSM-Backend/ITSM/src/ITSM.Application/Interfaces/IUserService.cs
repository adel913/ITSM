using ITSM.Application.DTOs.User;

namespace ITSM.Application.Interfaces;

public interface IUserService
{
    Task<List<UserDto>> GetAllAsync(Guid currentUserId, string role, Guid? departmentId);
    Task<UserDto?> GetByIdAsync(Guid id, Guid currentUserId, string role, Guid? departmentId);
    Task<UserDto> CreateAsync(CreateUserDto dto, Guid actingUserId);
    Task<UserDto> UpdateAsync(Guid id, UpdateUserDto dto, Guid actingUserId);
    Task DeleteAsync(Guid id, Guid actingUserId);
}
