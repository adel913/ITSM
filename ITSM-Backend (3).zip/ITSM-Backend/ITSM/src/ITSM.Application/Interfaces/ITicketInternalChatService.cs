using ITSM.Application.DTOs.InternalChat;

namespace ITSM.Application.Interfaces;

public interface ITicketInternalChatService
{
    Task<List<InternalMessageDto>> GetMessagesAsync(Guid ticketId);
    Task<InternalMessageDto> SendMessageAsync(SendInternalMessageDto dto, Guid senderId);
}
