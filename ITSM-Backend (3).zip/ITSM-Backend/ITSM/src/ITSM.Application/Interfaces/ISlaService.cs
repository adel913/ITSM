using ITSM.Application.DTOs.Sla;
using ITSM.Domain.Entities;
using ITSM.Domain.Enums;

namespace ITSM.Application.Interfaces;

public interface ISlaService
{
    Task<List<SlaPolicyDto>> GetAllAsync();
    Task<SlaPolicyDto> UpdateAsync(TicketPriority priority, UpdateSlaPolicyDto dto);
    Task<(DateTime responseDueAt, DateTime resolutionDueAt)> CalculateDueDatesAsync(TicketPriority priority, DateTime createdAtUtc);
    Task EvaluateBreachesAsync(Ticket ticket);
    Task PauseResolutionSlaAsync(Ticket ticket);
    Task ResumeResolutionSlaAsync(Ticket ticket);
}
