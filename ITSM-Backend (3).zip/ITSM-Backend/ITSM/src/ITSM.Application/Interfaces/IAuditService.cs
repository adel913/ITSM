namespace ITSM.Application.Interfaces;

public interface IAuditService
{
    Task LogAsync(Guid? userId, string action, string? details = null, string? ipAddress = null, string? entityType = null, string? entityId = null);
}
