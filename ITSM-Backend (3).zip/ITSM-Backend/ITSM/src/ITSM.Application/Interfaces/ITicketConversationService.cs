using ITSM.Application.DTOs.Conversation;

namespace ITSM.Application.Interfaces;

public interface ITicketConversationService
{
    Task<List<ConversationMessageDto>> GetMessagesAsync(Guid ticketId, Guid currentUserId);
    Task<ConversationMessageDto> SendMessageAsync(SendConversationMessageDto dto, Guid senderId);
}
