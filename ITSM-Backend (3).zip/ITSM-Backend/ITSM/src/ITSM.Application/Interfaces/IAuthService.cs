using ITSM.Application.DTOs.Auth;

namespace ITSM.Application.Interfaces;

public interface IAuthService
{
    Task<LoginResponseDto> LoginAsync(LoginRequestDto request);
    Task LogoutAsync(LogoutRequestDto request);
    Task<LoginResponseDto> RefreshTokenAsync(RefreshTokenRequestDto request);
    Task ForgotPasswordAsync(ForgotPasswordRequestDto request);
    Task ResetPasswordAsync(ResetPasswordRequestDto request, Guid adminUserId);
    Task ChangePasswordAsync(ChangePasswordRequestDto request, Guid adminUserId);
}
