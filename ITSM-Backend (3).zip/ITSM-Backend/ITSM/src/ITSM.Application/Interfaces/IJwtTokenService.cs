using ITSM.Domain.Entities;

namespace ITSM.Application.Interfaces;

public interface IJwtTokenService
{
    (string token, DateTime expiresAtUtc) GenerateAccessToken(User user, IEnumerable<string> permissions);
    string GenerateRefreshToken();
}
