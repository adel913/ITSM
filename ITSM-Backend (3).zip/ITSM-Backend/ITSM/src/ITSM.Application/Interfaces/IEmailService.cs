namespace ITSM.Application.Interfaces;

public interface IEmailService
{
    Task SendEmailAsync(string toEmail, string subject, string body);
    Task SendEmailToManyAsync(IEnumerable<string> toEmails, string subject, string body);
}
