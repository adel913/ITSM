using ITSM.Application.DTOs.Attachment;
using Microsoft.AspNetCore.Http;

namespace ITSM.Application.Interfaces;

public interface ITicketAttachmentService
{
    Task<List<TicketAttachmentDto>> GetForTicketAsync(Guid ticketId);
    Task<TicketAttachmentDto> UploadAsync(Guid ticketId, IFormFile file, Guid uploadedById);
    Task<(byte[] content, string contentType, string fileName)> DownloadAsync(Guid ticketId, Guid attachmentId);
}
