using ITSM.Application.DTOs.Notification;
using ITSM.Domain.Enums;

namespace ITSM.Application.Interfaces;

public interface INotificationService
{
    Task<List<NotificationDto>> GetForUserAsync(Guid userId);
    Task MarkAsReadAsync(Guid notificationId, Guid userId);
    Task NotifyUserAsync(Guid userId, NotificationEvent eventType, string title, string message);
    Task NotifyUsersAsync(IEnumerable<Guid> userIds, NotificationEvent eventType, string title, string message);
}
