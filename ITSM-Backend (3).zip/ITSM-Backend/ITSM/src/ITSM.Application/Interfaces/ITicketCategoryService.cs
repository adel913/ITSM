using ITSM.Application.DTOs.Category;

namespace ITSM.Application.Interfaces;

public interface ITicketCategoryService
{
    Task<List<TicketCategoryDto>> GetAllAsync();
    Task<TicketCategoryDto?> GetByIdAsync(Guid id);
    Task<TicketCategoryDto> CreateAsync(CreateTicketCategoryDto dto);
    Task<TicketCategoryDto> UpdateAsync(Guid id, UpdateTicketCategoryDto dto);
}
