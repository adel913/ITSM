using AutoMapper;
using ITSM.Application.DTOs.Attachment;
using ITSM.Application.DTOs.Category;
using ITSM.Application.DTOs.Conversation;
using ITSM.Application.DTOs.Department;
using ITSM.Application.DTOs.InternalChat;
using ITSM.Application.DTOs.Notification;
using ITSM.Application.DTOs.Sla;
using ITSM.Application.DTOs.Ticket;
using ITSM.Application.DTOs.User;
using ITSM.Domain.Entities;

namespace ITSM.Application.Mappings;

public class MappingProfile : Profile
{
    public MappingProfile()
    {
        CreateMap<User, UserDto>()
            .ForMember(d => d.DepartmentName, o => o.MapFrom(s => s.Department.Name))
            .ForMember(d => d.RoleName, o => o.MapFrom(s => s.Role.Name))
            .ForMember(d => d.UserStatus, o => o.MapFrom(s => s.UserStatus.ToString()));

        CreateMap<Department, DepartmentDto>()
            .ForMember(d => d.ManagerName, o => o.MapFrom(s => s.Manager != null ? s.Manager.FullName : null));

        CreateMap<TicketCategory, TicketCategoryDto>();

        CreateMap<Ticket, TicketDto>()
            .ForMember(d => d.CategoryName, o => o.MapFrom(s => s.Category.Name))
            .ForMember(d => d.DepartmentName, o => o.MapFrom(s => s.Department.Name))
            .ForMember(d => d.CreatedByName, o => o.MapFrom(s => s.CreatedBy.FullName))
            .ForMember(d => d.AssignedToName, o => o.MapFrom(s => s.AssignedTo != null ? s.AssignedTo.FullName : null))
            .ForMember(d => d.Status, o => o.MapFrom(s => s.Status.ToString()))
            .ForMember(d => d.Priority, o => o.MapFrom(s => s.Priority.ToString()));

        CreateMap<TicketConversationMessage, ConversationMessageDto>()
            .ForMember(d => d.SenderName, o => o.MapFrom(s => s.Sender.FullName));

        CreateMap<TicketInternalMessage, InternalMessageDto>()
            .ForMember(d => d.SenderName, o => o.MapFrom(s => s.Sender.FullName));

        CreateMap<SlaPolicy, SlaPolicyDto>()
            .ForMember(d => d.Priority, o => o.MapFrom(s => s.Priority.ToString()));

        CreateMap<Notification, NotificationDto>();

        CreateMap<TicketAttachment, TicketAttachmentDto>()
            .ForMember(d => d.UploadedByName, o => o.MapFrom(s => s.UploadedBy.FullName));
    }
}
