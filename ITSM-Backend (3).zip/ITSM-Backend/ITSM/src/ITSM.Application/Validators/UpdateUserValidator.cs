using FluentValidation;
using ITSM.Application.DTOs.User;

namespace ITSM.Application.Validators;

public class UpdateUserValidator : AbstractValidator<UpdateUserDto>
{
    public UpdateUserValidator()
    {
        RuleFor(x => x.FullName).NotEmpty();
        RuleFor(x => x.Email).NotEmpty().EmailAddress();
        RuleFor(x => x.DepartmentId).NotEmpty();
        RuleFor(x => x.RoleId).NotEmpty();
        RuleFor(x => x.UserStatus).NotEmpty().Must(s => new[] { "Active", "Inactive", "Suspended" }.Contains(s))
            .WithMessage("UserStatus must be Active, Inactive or Suspended");
    }
}
