using FluentValidation;
using ITSM.Application.DTOs.InternalChat;

namespace ITSM.Application.Validators;

public class SendInternalMessageValidator : AbstractValidator<SendInternalMessageDto>
{
    public SendInternalMessageValidator()
    {
        RuleFor(x => x.TicketId).NotEmpty();
        RuleFor(x => x.Message).NotEmpty();
    }
}
