using FluentValidation;
using ITSM.Application.DTOs.Category;

namespace ITSM.Application.Validators;

public class UpdateTicketCategoryValidator : AbstractValidator<UpdateTicketCategoryDto>
{
    public UpdateTicketCategoryValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(100);
    }
}
