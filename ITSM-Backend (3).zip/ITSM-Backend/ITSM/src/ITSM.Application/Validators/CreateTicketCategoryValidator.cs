using FluentValidation;
using ITSM.Application.DTOs.Category;

namespace ITSM.Application.Validators;

public class CreateTicketCategoryValidator : AbstractValidator<CreateTicketCategoryDto>
{
    public CreateTicketCategoryValidator()
    {
        RuleFor(x => x.Name).NotEmpty().MaximumLength(100);
    }
}
