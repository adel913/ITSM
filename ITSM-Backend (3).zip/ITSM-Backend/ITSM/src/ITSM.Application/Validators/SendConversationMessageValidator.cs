using FluentValidation;
using ITSM.Application.DTOs.Conversation;

namespace ITSM.Application.Validators;

public class SendConversationMessageValidator : AbstractValidator<SendConversationMessageDto>
{
    public SendConversationMessageValidator()
    {
        RuleFor(x => x.TicketId).NotEmpty();
        RuleFor(x => x.Message).NotEmpty();
    }
}
