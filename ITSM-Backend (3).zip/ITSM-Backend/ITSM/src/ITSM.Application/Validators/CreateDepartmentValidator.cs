using FluentValidation;
using ITSM.Application.DTOs.Department;

namespace ITSM.Application.Validators;

public class CreateDepartmentValidator : AbstractValidator<CreateDepartmentDto>
{
    public CreateDepartmentValidator()
    {
        RuleFor(x => x.Name).NotEmpty();
    }
}
