using FluentValidation;
using ITSM.Application.DTOs.Ticket;

namespace ITSM.Application.Validators;

public class ChangeTicketStatusValidator : AbstractValidator<ChangeTicketStatusDto>
{
    private static readonly string[] AllowedTransitions = { "PendingUser", "PendingVendor", "InProgress", "Cancelled" };

    public ChangeTicketStatusValidator()
    {
        RuleFor(x => x.Status).NotEmpty().Must(s => AllowedTransitions.Contains(s))
            .WithMessage($"Status must be one of: {string.Join(", ", AllowedTransitions)}");
    }
}
