using FluentValidation;
using ITSM.Application.DTOs.Department;

namespace ITSM.Application.Validators;

public class UpdateDepartmentValidator : AbstractValidator<UpdateDepartmentDto>
{
    public UpdateDepartmentValidator()
    {
        RuleFor(x => x.Name).NotEmpty();
    }
}
