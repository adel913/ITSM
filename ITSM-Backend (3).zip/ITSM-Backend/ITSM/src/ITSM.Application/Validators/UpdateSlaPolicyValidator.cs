using FluentValidation;
using ITSM.Application.DTOs.Sla;

namespace ITSM.Application.Validators;

public class UpdateSlaPolicyValidator : AbstractValidator<UpdateSlaPolicyDto>
{
    public UpdateSlaPolicyValidator()
    {
        RuleFor(x => x.ResponseMinutes).GreaterThan(0);
        RuleFor(x => x.ResolutionMinutes).GreaterThan(0);
    }
}
