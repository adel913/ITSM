namespace ITSM.Application.DTOs.Conversation;

public class SendConversationMessageDto
{
    public Guid TicketId { get; set; }
    public string Message { get; set; } = string.Empty;
}
