namespace ITSM.Application.DTOs.InternalChat;

public class SendInternalMessageDto
{
    public Guid TicketId { get; set; }
    public string Message { get; set; } = string.Empty;
}
