namespace ITSM.Application.DTOs.Auth;

// Admin resets user password only (per spec: Change Password = Admin resets user's password)
public class ChangePasswordRequestDto
{
    public Guid TargetUserId { get; set; }
    public string NewPassword { get; set; } = string.Empty;
}
