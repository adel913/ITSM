namespace ITSM.Application.DTOs.Auth;

// Admin-only: Admin resets the target user's password directly.
public class ResetPasswordRequestDto
{
    public Guid TargetUserId { get; set; }
    public string NewPassword { get; set; } = string.Empty;
}
