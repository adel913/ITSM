namespace ITSM.Application.DTOs.Ticket;

public class UpdateTicketDto
{
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public Guid CategoryId { get; set; }
    public string Priority { get; set; } = "Medium";
}
