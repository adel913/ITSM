namespace ITSM.Application.DTOs.Ticket;

// Used for PendingUser / PendingVendor / Cancelled transitions which pause/affect Resolution SLA.
public class ChangeTicketStatusDto
{
    public string Status { get; set; } = string.Empty;
}
