namespace ITSM.Application.DTOs.Ticket;

public class TicketDto
{
    public Guid Id { get; set; }
    public string TicketNumber { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;

    public Guid CategoryId { get; set; }
    public string CategoryName { get; set; } = string.Empty;

    // Additive fields (hardening item 3): expose the department the ticket is scoped to.
    public Guid DepartmentId { get; set; }
    public string DepartmentName { get; set; } = string.Empty;

    public Guid CreatedById { get; set; }
    public string CreatedByName { get; set; } = string.Empty;

    public Guid? AssignedToId { get; set; }
    public string? AssignedToName { get; set; }

    public string Status { get; set; } = string.Empty;
    public string Priority { get; set; } = string.Empty;

    public DateTime CreatedAt { get; set; }
    public DateTime? AssignedAt { get; set; }
    public DateTime? FirstResponseAt { get; set; }
    public DateTime? ResolvedAt { get; set; }
    public DateTime? ClosedAt { get; set; }

    public DateTime? ResponseDueAt { get; set; }
    public DateTime? ResolutionDueAt { get; set; }
    public bool IsResponseSlaBreached { get; set; }
    public bool IsResolutionSlaBreached { get; set; }
    public int TotalPausedMinutes { get; set; }
}
