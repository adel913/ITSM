namespace ITSM.Application.DTOs.Category;

public class CreateTicketCategoryDto
{
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
}
