namespace ITSM.Application.DTOs.Sla;

public class UpdateSlaPolicyDto
{
    public int ResponseMinutes { get; set; }
    public int ResolutionMinutes { get; set; }
}
