namespace ITSM.Application.DTOs.Sla;

public class SlaPolicyDto
{
    public Guid Id { get; set; }
    public string Priority { get; set; } = string.Empty;
    public int ResponseMinutes { get; set; }
    public int ResolutionMinutes { get; set; }
}
