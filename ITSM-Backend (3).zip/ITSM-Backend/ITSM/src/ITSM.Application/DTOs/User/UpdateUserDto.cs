namespace ITSM.Application.DTOs.User;

public class UpdateUserDto
{
    public string FullName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public Guid DepartmentId { get; set; }
    public Guid RoleId { get; set; }
    public string UserStatus { get; set; } = string.Empty;
}
